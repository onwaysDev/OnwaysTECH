import LegalPage from "../legal/LegalPage";

export default function ConditionsUtilisationPage() {
  return (
    <LegalPage
      eyebrow="RÈGLES D’UTILISATION"
      title="Conditions d’utilisation"
      intro="En consultant ce site, vous acceptez les règles ci-dessous, conçues pour protéger les visiteurs, les contenus et les services OnwaysTech."
      sections={[
        {
          title: "Accès au site",
          paragraphs: [
            "L’accès au site est proposé gratuitement, hors coûts de connexion de l’utilisateur. OnwaysTech peut modifier, suspendre ou interrompre une partie du site pour maintenance, sécurité ou évolution fonctionnelle.",
          ],
        },
        {
          title: "Utilisation autorisée",
          items: [
            "consulter les informations et découvrir les services OnwaysTech ;",
            "utiliser le configurateur de devis de bonne foi ;",
            "transmettre des informations exactes et licites ;",
            "respecter les droits de propriété intellectuelle et la sécurité du site.",
          ],
        },
        {
          title: "Usages interdits",
          items: [
            "tenter d’accéder sans autorisation au site ou à ses systèmes ;",
            "introduire un programme malveillant ou perturber le service ;",
            "extraire massivement les contenus ou les réutiliser commercialement sans accord ;",
            "usurper une identité ou transmettre un contenu illicite, trompeur ou portant atteinte à un tiers.",
          ],
        },
        {
          title: "Devis et prestations",
          paragraphs: [
            "Les estimations affichées par le configurateur sont préliminaires. Une prestation n’est engagée qu’après validation du périmètre, émission d’une proposition commerciale et acceptation des conditions contractuelles correspondantes.",
          ],
        },
        {
          title: "Limitation de responsabilité",
          paragraphs: [
            "OnwaysTech ne garantit pas que le site sera exempt de toute interruption ou erreur. Dans les limites permises par la loi, sa responsabilité ne peut être engagée pour un dommage indirect résultant de l’utilisation du site ou d’un service tiers.",
          ],
        },
        {
          title: "Modification et contact",
          paragraphs: [
            "Ces conditions peuvent être mises à jour. La version applicable est celle publiée sur le site à la date de consultation. Pour toute question : contact@onways.tech.",
          ],
        },
      ]}
    />
  );
}
