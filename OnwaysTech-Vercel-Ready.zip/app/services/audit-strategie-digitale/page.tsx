import ServiceDetail, { serviceConfigs } from "../ServiceDetail";

export default function AuditStrategieDigitalePage() {
  return <ServiceDetail service={serviceConfigs["audit-strategie-digitale"]} />;
}
