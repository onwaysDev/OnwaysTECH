import ServiceDetail, { serviceConfigs } from "../ServiceDetail";

export default function PilotageDigitalPage() {
  return <ServiceDetail service={serviceConfigs["pilotage-digital"]} />;
}
