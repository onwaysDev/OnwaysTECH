import ServiceDetail, { serviceConfigs } from "../ServiceDetail";

export default function ApplicationsUtilesPage() {
  return <ServiceDetail service={serviceConfigs["applications-utiles"]} />;
}
