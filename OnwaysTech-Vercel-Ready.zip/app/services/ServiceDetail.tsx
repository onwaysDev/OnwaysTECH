import {
  ArrowLeft,
  ArrowRight,
  BarChart3,
  CalendarDays,
  Check,
  CheckCircle2,
  ClipboardCheck,
  CloudCog,
  CreditCard,
  Laptop,
  LineChart,
  LockKeyhole,
  Mail,
  SearchCheck,
  ShieldCheck,
  Smartphone,
  Sparkles,
  TrendingUp,
  UserRound,
  Workflow,
  Zap,
} from "lucide-react";
import Link from "next/link";

export type ServiceSlug =
  | "applications-utiles"
  | "audit-strategie-digitale"
  | "solutions-saas"
  | "projets-monetisables"
  | "pilotage-digital"
  | "etude-prealable";

export type ServiceConfig = {
  slug: ServiceSlug;
  number: string;
  title: string;
  eyebrow: string;
  headline: string;
  accent: string;
  description: string;
  promise: string;
  startingPrice: string;
  duration: string;
  forWho: string[];
  outcomes: string[];
  deliverables: { title: string; text: string }[];
  steps: { number: string; title: string; text: string }[];
};

export const serviceConfigs: Record<ServiceSlug, ServiceConfig> = {
  "applications-utiles": {
    slug: "applications-utiles",
    number: "01",
    title: "Applications utiles",
    eyebrow: "Applications web & mobiles",
    headline: "Une application pensée",
    accent: "pour être vraiment utilisée.",
    description: "Nous transformons votre besoin en une application web ou mobile simple, performante et adaptée aux usages réels de vos clients, collaborateurs ou partenaires.",
    promise: "Passer d’une idée à une solution numérique claire, fiable et évolutive.",
    startingPrice: "À partir de 1 500 000 FCFA",
    duration: "8 à 16 semaines",
    forWho: ["Entreprises", "Institutions", "Startups", "Associations"],
    outcomes: ["Parcours utilisateur simplifié", "Interface responsive", "Administration sécurisée", "Base technique évolutive"],
    deliverables: [
      { title: "Cadrage fonctionnel", text: "Besoins, utilisateurs, fonctionnalités, priorités et critères de réussite." },
      { title: "Design de l’expérience", text: "Architecture des écrans, parcours et interface cohérente avec votre identité." },
      { title: "Développement complet", text: "Application web ou mobile, espace administrateur et intégrations nécessaires." },
      { title: "Mise en production", text: "Tests, corrections, déploiement, formation et accompagnement au lancement." },
    ],
    steps: [
      { number: "01", title: "Comprendre", text: "Nous analysons le problème, les utilisateurs et l’environnement du projet." },
      { number: "02", title: "Concevoir", text: "Nous définissons le parcours, les écrans et la version prioritaire du produit." },
      { number: "03", title: "Développer", text: "Nous construisons par étapes avec des validations régulières." },
      { number: "04", title: "Lancer", text: "Nous testons, mettons en ligne et préparons l’évolution de la solution." },
    ],
  },
  "audit-strategie-digitale": {
    slug: "audit-strategie-digitale",
    number: "02",
    title: "Audit et stratégie digitale",
    eyebrow: "Diagnostic & recommandations",
    headline: "Voir clairement.",
    accent: "Décider avec méthode.",
    description: "Nous évaluons votre projet, votre site, votre produit ou votre organisation numérique afin d’identifier les faiblesses, les risques et les opportunités prioritaires.",
    promise: "Obtenir une feuille de route concrète avant d’investir davantage.",
    startingPrice: "À partir de 300 000 FCFA",
    duration: "1 à 3 semaines",
    forWho: ["Dirigeants", "Porteurs de projet", "PME", "Organisations"],
    outcomes: ["Diagnostic objectif", "Priorités identifiées", "Risques anticipés", "Plan d’action exploitable"],
    deliverables: [
      { title: "État des lieux", text: "Analyse de l’existant, des objectifs, des outils, du marché et des usages." },
      { title: "Diagnostic détaillé", text: "Forces, faiblesses, incohérences, risques techniques et opportunités." },
      { title: "Recommandations", text: "Décisions concrètes classées par urgence, impact, coût et faisabilité." },
      { title: "Feuille de route", text: "Plan d’action séquencé avec priorités, ressources et prochaines étapes." },
    ],
    steps: [
      { number: "01", title: "Collecter", text: "Entretiens, documents, accès et compréhension du contexte." },
      { number: "02", title: "Analyser", text: "Étude des parcours, outils, performances et choix actuels." },
      { number: "03", title: "Recommander", text: "Arbitrages et solutions adaptés à vos contraintes réelles." },
      { number: "04", title: "Planifier", text: "Restitution et feuille de route prête à être exécutée." },
    ],
  },
  "solutions-saas": {
    slug: "solutions-saas",
    number: "03",
    title: "Création de solutions SaaS",
    eyebrow: "Plateformes numériques évolutives",
    headline: "Construire un service",
    accent: "accessible partout.",
    description: "Nous concevons des plateformes SaaS accessibles en ligne, structurées pour accueillir plusieurs utilisateurs, évoluer dans le temps et soutenir un modèle d’abonnement.",
    promise: "Créer une plateforme fiable qui peut grandir avec son marché.",
    startingPrice: "À partir de 3 000 000 FCFA",
    duration: "12 à 24 semaines",
    forWho: ["Startups", "Experts métier", "Entreprises", "Éditeurs"],
    outcomes: ["Architecture multi-utilisateur", "Abonnements structurés", "Administration centralisée", "Évolutivité maîtrisée"],
    deliverables: [
      { title: "Modèle SaaS", text: "Utilisateurs, rôles, offres, abonnements, limites et logique de revenus." },
      { title: "Expérience produit", text: "Onboarding, tableau de bord, parcours clés et gestion du compte." },
      { title: "Plateforme sécurisée", text: "Développement, données, permissions, paiements et intégrations." },
      { title: "Outils de pilotage", text: "Administration, métriques d’usage, suivi des abonnements et support." },
    ],
    steps: [
      { number: "01", title: "Valider le modèle", text: "Nous clarifions la cible, la valeur et la logique d’abonnement." },
      { number: "02", title: "Définir le MVP", text: "Nous retenons les fonctions indispensables au premier lancement." },
      { number: "03", title: "Construire", text: "La plateforme est développée en modules testables et évolutifs." },
      { number: "04", title: "Faire grandir", text: "Lancement, mesure des usages et plan des prochaines versions." },
    ],
  },
  "projets-monetisables": {
    slug: "projets-monetisables",
    number: "04",
    title: "Développement de projets monétisables",
    eyebrow: "Produit & modèle économique",
    headline: "Transformer une idée",
    accent: "en activité numérique.",
    description: "Nous structurons votre idée comme un véritable produit commercialisable, avec une cible, une proposition de valeur, une offre et un mécanisme de revenus cohérent.",
    promise: "Ne pas seulement créer un outil : bâtir un produit capable de générer de la valeur.",
    startingPrice: "À partir de 2 500 000 FCFA",
    duration: "10 à 20 semaines",
    forWho: ["Entrepreneurs", "Créateurs", "Investisseurs", "Organisations"],
    outcomes: ["Proposition de valeur claire", "Modèle économique viable", "Produit minimum commercialisable", "Plan de lancement"],
    deliverables: [
      { title: "Concept structuré", text: "Problème, cible, solution, différenciation et hypothèses à vérifier." },
      { title: "Modèle de revenus", text: "Tarification, coûts, canaux de vente et indicateurs économiques." },
      { title: "Produit commercialisable", text: "Conception et développement de la première version vendable." },
      { title: "Plan de croissance", text: "Acquisition, lancement, mesure, amélioration et évolution du produit." },
    ],
    steps: [
      { number: "01", title: "Clarifier l’idée", text: "Nous transformons l’intuition en proposition de valeur précise." },
      { number: "02", title: "Tester la viabilité", text: "Nous étudions la cible, le marché, les coûts et les revenus." },
      { number: "03", title: "Créer le produit", text: "Nous développons une version centrée sur la valeur commerciale." },
      { number: "04", title: "Préparer la vente", text: "Offre, tarification, lancement et indicateurs de croissance." },
    ],
  },
  "pilotage-digital": {
    slug: "pilotage-digital",
    number: "05",
    title: "Pilotage digital",
    eyebrow: "Direction & coordination de projet",
    headline: "Garder le cap.",
    accent: "Maîtriser chaque étape.",
    description: "Nous organisons, coordonnons et suivons votre projet numérique de la conception à la mise en production, en faisant le lien entre les métiers, les prestataires et les décideurs.",
    promise: "Donner au projet une direction claire, un rythme et une responsabilité.",
    startingPrice: "À partir de 750 000 FCFA",
    duration: "Selon le projet",
    forWho: ["Directions", "PME", "Institutions", "Équipes projet"],
    outcomes: ["Planning maîtrisé", "Responsabilités claires", "Risques suivis", "Décisions documentées"],
    deliverables: [
      { title: "Organisation du projet", text: "Objectifs, gouvernance, rôles, planning, jalons et outils de suivi." },
      { title: "Coordination des acteurs", text: "Réunions, arbitrages et circulation fiable de l’information." },
      { title: "Suivi qualité & risques", text: "Contrôle des livrables, alertes, dépendances et actions correctives." },
      { title: "Reporting décisionnel", text: "Tableaux de bord, comptes rendus et visibilité régulière pour la direction." },
    ],
    steps: [
      { number: "01", title: "Organiser", text: "Nous définissons les responsabilités, méthodes et jalons." },
      { number: "02", title: "Coordonner", text: "Nous alignons les équipes internes et les prestataires." },
      { number: "03", title: "Contrôler", text: "Nous suivons délais, qualité, budget, risques et décisions." },
      { number: "04", title: "Livrer", text: "Nous accompagnons la recette et la mise en production." },
    ],
  },
  "etude-prealable": {
    slug: "etude-prealable",
    number: "06",
    title: "Étude préalable du projet web",
    eyebrow: "Faisabilité avant développement",
    headline: "Étudier d’abord.",
    accent: "Investir ensuite.",
    description: "Avant le développement, nous étudions les besoins, les fonctionnalités, les utilisateurs, les contraintes techniques, le budget prévisionnel et les délais.",
    promise: "Savoir précisément quoi construire, pourquoi, comment et à quel coût.",
    startingPrice: "À partir de 250 000 FCFA",
    duration: "1 à 3 semaines",
    forWho: ["Porteurs d’idée", "Entreprises", "Associations", "Institutions"],
    outcomes: ["Périmètre défini", "Faisabilité vérifiée", "Budget prévisionnel", "Décision sécurisée"],
    deliverables: [
      { title: "Expression du besoin", text: "Objectifs, utilisateurs, usages, contraintes et résultats attendus." },
      { title: "Périmètre fonctionnel", text: "Modules, fonctionnalités, priorités et version initiale recommandée." },
      { title: "Orientation technique", text: "Architecture, technologies, intégrations, sécurité et hébergement." },
      { title: "Estimation du projet", text: "Budget, délais, risques, phases et recommandations de réalisation." },
    ],
    steps: [
      { number: "01", title: "Interroger", text: "Nous recueillons l’idée, les objectifs et les contraintes." },
      { number: "02", title: "Structurer", text: "Nous organisons les besoins et définissons les priorités." },
      { number: "03", title: "Évaluer", text: "Nous estimons faisabilité, technologies, budget et délais." },
      { number: "04", title: "Recommander", text: "Vous recevez un dossier clair pour décider et lancer le projet." },
    ],
  },
};

const icons = {
  "applications-utiles": Smartphone,
  "audit-strategie-digitale": SearchCheck,
  "solutions-saas": CloudCog,
  "projets-monetisables": TrendingUp,
  "pilotage-digital": Workflow,
  "etude-prealable": ClipboardCheck,
};

export default function ServiceDetail({ service }: { service: ServiceConfig }) {
  const Icon = icons[service.slug];
  const isUsefulApps = service.slug === "applications-utiles";
  const isAudit = service.slug === "audit-strategie-digitale";
  const isSaas = service.slug === "solutions-saas";
  const isMonetizable = service.slug === "projets-monetisables";
  const isPilot = service.slug === "pilotage-digital";
  const isStudy = service.slug === "etude-prealable";

  return (
    <main className={`service-detail-page service-${service.slug}`}>
      <header className="detail-header">
        <Link className="brand" href="/" aria-label="Retour à OnwaysTech">
          <span className="brand-mark" aria-hidden="true"><span /></span>
          <span className="brand-name">Onways<span>.tech</span></span>
        </Link>
        <nav className="detail-nav" aria-label="Navigation du service">
          <Link href="/">Accueil</Link>
          <Link href="/#produits">Produits</Link>
          <Link href="/#services" className="active">Services</Link>
          <Link href="/#devis">Devis</Link>
        </nav>
        <Link className="detail-contact" href="/#devis">
          <Mail aria-hidden="true" /> Demander un devis
        </Link>
      </header>

      <section className="service-detail-hero">
        <div className="service-detail-copy">
          <Link className="back-products" href="/#services"><ArrowLeft /> Tous les services</Link>
          <p className="detail-eyebrow"><span /> Service {service.number} · {service.eyebrow}</p>
          <h1>{service.headline}<em>{service.accent}</em></h1>
          <p className="detail-description">{service.description}</p>
          <div className="detail-actions">
            <Link className="detail-primary" href="/#devis">Étudier mon projet <ArrowRight /></Link>
            <a className="service-outline-action" href="#comprendre">Comprendre le service</a>
          </div>
          <div className="service-quick-facts">
            <div><small>BUDGET INDICATIF</small><strong>{service.startingPrice}</strong></div>
            <div><small>DÉLAI MOYEN</small><strong>{service.duration}</strong></div>
          </div>
        </div>

        {isUsefulApps ? (
          <div className="service-detail-visual useful-apps-animation" aria-label="Animation illustrant une application web et mobile qui simplifie une tâche quotidienne">
            <div className="useful-apps-glow" />

            <div className="task-cloud task-calendar"><CalendarDays aria-hidden="true" /><span>Réserver</span></div>
            <div className="task-cloud task-payment"><CreditCard aria-hidden="true" /><span>Payer</span></div>
            <div className="task-cloud task-manage"><ClipboardCheck aria-hidden="true" /><span>Gérer</span></div>

            <div className="web-device" aria-hidden="true">
              <div className="device-browser-bar"><i /><i /><i /><span /></div>
              <div className="device-web-content">
                <div className="web-sidebar"><b /><b /><b /></div>
                <div className="web-dashboard">
                  <span className="ui-title" />
                  <div className="ui-stat-row"><i /><i /><i /></div>
                  <span className="ui-chart"><b /><b /><b /><b /></span>
                </div>
              </div>
              <Laptop className="device-mark" />
            </div>

            <div className="mobile-device" aria-hidden="true">
              <span className="phone-speaker" />
              <div className="mobile-app-screen">
                <b>MON ESPACE</b>
                <i className="mobile-avatar"><UserRound /></i>
                <span className="mobile-line" />
                <span className="mobile-line short" />
                <button tabIndex={-1}><Check /> Valider</button>
              </div>
              <span className="tap-ring" />
            </div>

            <div className="useful-result" aria-hidden="true">
              <CheckCircle2 />
              <span><b>Action réussie</b><small>Simple et immédiat</small></span>
            </div>
            <div className="quality-chip quality-speed"><Zap /><span>Rapide</span></div>
            <div className="quality-chip quality-security"><LockKeyhole /><span>Sécurisé</span></div>

            <div className="useful-apps-signature">
              <small>APPLICATIONS UTILES</small>
              <strong>Des solutions web et mobiles<br />pensées pour vos besoins réels.</strong>
            </div>
          </div>
        ) : isAudit ? (
          <div className="service-detail-visual audit-animation" aria-label="Animation d’audit d’un site et d’une application, du diagnostic à la stratégie">
            <div className="audit-ambient" aria-hidden="true" />
            <div className="audit-stage-labels" aria-hidden="true">
              <span>ANALYSE</span><span>DIAGNOSTIC</span><span>STRATÉGIE</span>
            </div>

            <div className="audit-workspace" aria-hidden="true">
              <div className="audit-browser">
                <div className="audit-browser-bar"><i /><i /><i /><b /></div>
                <div className="audit-site">
                  <aside><i /><i /><i /><i /></aside>
                  <section>
                    <b className="audit-hero-line" />
                    <div className="audit-cards"><i /><i /><i /></div>
                    <span className="audit-chart"><em /><em /><em /><em /></span>
                  </section>
                </div>
                <span className="audit-scan-line" />
                <span className="audit-issue issue-a">Navigation</span>
                <span className="audit-issue issue-b">Lenteur</span>
                <span className="audit-issue issue-c">Conversion</span>
                <span className="audit-issue issue-d">Visibilité</span>
                <span className="audit-issue issue-e">Performance</span>
              </div>

              <div className="audit-phone">
                <span />
                <b />
                <i /><i /><i />
                <em className="audit-phone-scan" />
              </div>
            </div>

            <div className="audit-metrics" aria-hidden="true">
              <div><small>PERFORMANCE</small><strong>42</strong><b><i /></b></div>
              <div><small>VISIBILITÉ</small><strong>38</strong><b><i /></b></div>
              <div><small>CONVERSION</small><strong>1,2%</strong><b><i /></b></div>
            </div>

            <div className="audit-recommendations" aria-hidden="true">
              <span><Sparkles /> Expérience utilisateur</span>
              <span><Zap /> Performances</span>
              <span><BarChart3 /> Visibilité numérique</span>
              <span><ShieldCheck /> Parcours clarifié</span>
              <span><TrendingUp /> Stratégie de croissance</span>
            </div>

            <div className="audit-roadmap" aria-hidden="true">
              {["Analyse", "Diagnostic", "Recommandations", "Stratégie", "Résultats"].map((step, index) => (
                <span key={step} style={{ "--audit-step": index } as React.CSSProperties}>
                  <i>{index + 1}</i><b>{step}</b>
                </span>
              ))}
            </div>

            <div className="audit-success" aria-hidden="true">
              <LineChart />
              <span><small>STRATÉGIE DIGITALE</small><strong>Comprendre. Optimiser. Accélérer.</strong></span>
            </div>
          </div>
        ) : isSaas ? (
          <div className="service-detail-visual saas-animation" aria-label="Animation montrant la transformation d’une idée en plateforme SaaS accessible sur tous les écrans">
            <div className="saas-idea" aria-hidden="true"><Sparkles /><span>IDÉE SaaS</span></div>
            <div className="saas-sketch" aria-hidden="true"><i /><i /><i /><b /><b /></div>

            <div className="saas-platform" aria-hidden="true">
              <div className="saas-browser-bar"><i /><i /><i /><b>ONWAYSTECH CLOUD</b></div>
              <div className="saas-platform-body">
                <aside><CloudCog /><i /><i /><i /><i /></aside>
                <section>
                  <div className="saas-welcome"><span><small>TABLEAU DE BORD</small><strong>Votre plateforme évolue</strong></span><b>+24%</b></div>
                  <div className="saas-kpis"><i /><i /><i /></div>
                  <div className="saas-chart"><span /><span /><span /><span /><span /><span /></div>
                </section>
              </div>
              <span className="saas-build-line" />
            </div>

            <div className="saas-phone" aria-hidden="true"><i /><CloudCog /><span /><span /><button tabIndex={-1}>OUVRIR</button></div>
            <div className="saas-tablet" aria-hidden="true"><b /><span><i /><i /><i /></span><BarChart3 /></div>

            <div className="saas-modules" aria-hidden="true">
              <span><UserRound /> Espace utilisateur</span>
              <span><LockKeyhole /> Connexion sécurisée</span>
              <span><CreditCard /> Abonnements</span>
              <span><BarChart3 /> Statistiques</span>
              <span><CloudCog /> Administration</span>
            </div>

            <div className="saas-subscribers" aria-hidden="true">
              <span><UserRound /></span><span><UserRound /></span><span><UserRound /></span><span><UserRound /></span>
              <b>Abonnés en croissance</b>
            </div>

            <div className="saas-roadmap" aria-hidden="true">
              {["Idée", "Conception", "Développement", "Mise en ligne", "Abonnements", "Croissance"].map((step, index) => (
                <span key={step} style={{ "--saas-step": index } as React.CSSProperties}><i>{index + 1}</i><b>{step}</b></span>
              ))}
            </div>

            <div className="saas-success" aria-hidden="true">
              <TrendingUp /><span><small>CRÉATION DE SOLUTIONS SaaS</small><strong>Une plateforme accessible, évolutive et monétisable.</strong></span>
            </div>
          </div>
        ) : isMonetizable ? (
          <div className="service-detail-visual monetizable-animation" aria-label="Animation montrant la transformation d’une idée en produit numérique commercialisable">
            <div className="money-spark" aria-hidden="true"><Sparkles /></div>
            <div className="money-fragments" aria-hidden="true">
              {["Idée", "Besoins", "Interface", "Données", "Fonctions", "Revenus"].map((item, index) => (
                <span key={item} style={{ "--money-fragment": index } as React.CSSProperties}>{item}</span>
              ))}
            </div>
            <div className="money-product" aria-hidden="true">
              <div className="money-laptop">
                <div className="money-top"><i /><i /><i /><b /></div>
                <div className="money-dashboard">
                  <aside><i /><i /><i /></aside>
                  <section><b /><div><i /><i /><i /></div><span><em /><em /><em /><em /></span></section>
                </div>
              </div>
              <div className="money-phone"><i /><b /><span /><span /><button tabIndex={-1}>PAYER</button></div>
            </div>
            <div className="money-features" aria-hidden="true">
              <span><CreditCard /> Paiement sécurisé</span>
              <span><Smartphone /> Web & mobile</span>
              <span><BarChart3 /> Tableau analytique</span>
              <span><TrendingUp /> Produit évolutif</span>
            </div>
            <div className="money-revenue" aria-hidden="true">
              {["Abonnement", "Achat", "Commission", "Transaction"].map((item) => <span key={item}><Check />{item}</span>)}
            </div>
            <div className="money-roadmap" aria-hidden="true">
              {["Idée", "Étude", "Conception", "Développement", "Lancement", "Revenus"].map((step, index) => (
                <span key={step} style={{ "--money-step": index } as React.CSSProperties}><i>{index + 1}</i><b>{step}</b></span>
              ))}
            </div>
            <div className="money-success" aria-hidden="true">
              <LineChart /><span><small>PRODUIT OPÉRATIONNEL</small><strong>De l’idée au produit. Du produit aux revenus.</strong></span>
            </div>
          </div>
        ) : isPilot ? (
          <div className="service-detail-visual pilot-animation" aria-label="Animation d’un tableau de pilotage qui coordonne les équipes, les tâches, le budget et le lancement">
            <div className="pilot-scatter" aria-hidden="true">
              {["Tâches", "Équipes", "Calendrier", "Budget", "Maquettes", "Tests", "Objectifs"].map((item, index) => (
                <span key={item} style={{ "--pilot-item": index } as React.CSSProperties}>{item}</span>
              ))}
            </div>
            <div className="pilot-board" aria-hidden="true">
              <div className="pilot-board-top"><Workflow /><b>PILOTAGE DU PROJET</b><span>EN DIRECT</span></div>
              <div className="pilot-board-body">
                <aside><i /><i /><i /><i /></aside>
                <section>
                  <div className="pilot-kpis"><span><small>PROGRESSION</small><strong>100%</strong></span><span><small>QUALITÉ</small><strong>Validée</strong></span><span><small>BUDGET</small><strong>Suivi</strong></span></div>
                  <div className="pilot-tasks">{["Architecture", "Design", "Développement", "Tests"].map((task, index) => <span key={task} style={{ "--pilot-task": index } as React.CSSProperties}><Check />{task}<i /></span>)}</div>
                </section>
              </div>
              <div className="pilot-progress"><i /></div>
            </div>
            <div className="pilot-flow" aria-hidden="true">
              {["Planification", "Coordination", "Suivi", "Contrôle", "Mise en production"].map((step, index) => (
                <span key={step} style={{ "--pilot-step": index } as React.CSSProperties}><i>{index + 1}</i><b>{step}</b></span>
              ))}
            </div>
            <div className="pilot-launch" aria-hidden="true"><CheckCircle2 /><span><small>EN DÉVELOPPEMENT</small><strong>Projet lancé</strong></span></div>
            <div className="pilot-message" aria-hidden="true">Une vision claire. Un projet maîtrisé.</div>
          </div>
        ) : isStudy ? (
          <div className="service-detail-visual study-animation" aria-label="Animation d’une étude préalable qui transforme une idée imprécise en cahier des charges structuré">
            <div className="study-inputs" aria-hidden="true">
              {["Objectifs", "Fonctionnalités", "Budget", "Utilisateurs", "Contraintes", "Délais"].map((item, index) => (
                <span key={item} style={{ "--study-input": index } as React.CSSProperties}>{item}</span>
              ))}
            </div>
            <div className="study-document" aria-hidden="true">
              <div className="study-doc-head"><ClipboardCheck /><span><small>ÉTUDE PRÉALABLE</small><strong>Analyse du projet web</strong></span><b>06</b></div>
              <div className="study-doc-body">
                <div className="study-scan" />
                {["Objectifs du projet", "Utilisateurs cibles", "Marché & solutions", "Fonctions prioritaires", "Faisabilité technique", "Risques", "Budget & délais", "Architecture"].map((item, index) => (
                  <span key={item} style={{ "--study-row": index } as React.CSSProperties}><i><Check /></i><b>{item}</b><em /></span>
                ))}
              </div>
            </div>
            <div className="study-wireframe" aria-hidden="true"><Laptop /><span><i /><i /><i /></span></div>
            <div className="study-roadmap" aria-hidden="true">
              {["Idée", "Analyse du besoin", "Faisabilité", "Fonctionnalités", "Estimation", "Cahier des charges"].map((step, index) => (
                <span key={step} style={{ "--study-step": index } as React.CSSProperties}><i>{index + 1}</i><b>{step}</b></span>
              ))}
            </div>
            <div className="study-validations" aria-hidden="true">
              {["Objectifs définis", "Faisabilité confirmée", "Budget estimé", "Planning structuré"].map((item) => <span key={item}><CheckCircle2 />{item}</span>)}
            </div>
            <div className="study-message" aria-hidden="true">Bien étudier avant de construire.</div>
          </div>
        ) : (
          <div className="service-detail-visual" aria-label={`Présentation du service ${service.title}`}>
            <div className="service-orbit service-orbit-wide" />
            <div className="service-orbit service-orbit-small" />
            <div className="service-number-giant">{service.number}</div>
            <div className="service-icon-hero"><Icon aria-hidden="true" /></div>
            <div className="service-promise-card">
              <small>NOTRE ENGAGEMENT</small>
              <strong>{service.promise}</strong>
              <div className="promise-line"><i /><i /><i /></div>
            </div>
            {service.outcomes.slice(0, 3).map((outcome, index) => (
              <div className={`service-floating-result result-${index + 1}`} key={outcome}>
                <Check aria-hidden="true" /><span>{outcome}</span>
              </div>
            ))}
          </div>
        )}
      </section>

      <section className="service-explanation" id="comprendre">
        <div className="service-section-intro">
          <p className="detail-eyebrow"><span /> Ce que vous obtenez</p>
          <h2>Un service complet,<br /><em>des résultats concrets.</em></h2>
          <p>{service.promise}</p>
        </div>
        <div className="service-deliverables">
          {service.deliverables.map((item, index) => (
            <article key={item.title} style={{ "--service-delay": `${index * 90}ms` } as React.CSSProperties}>
              <span>{String(index + 1).padStart(2, "0")}</span>
              <div><h3>{item.title}</h3><p>{item.text}</p></div>
            </article>
          ))}
        </div>
      </section>

      <section className="service-process">
        <div className="service-process-heading">
          <small>MÉTHODE ONWAYSTECH</small>
          <h2>Un parcours maîtrisé,<br />du besoin au résultat.</h2>
        </div>
        <div className="service-process-grid">
          {service.steps.map((step) => (
            <article key={step.number}>
              <b>{step.number}</b>
              <div><h3>{step.title}</h3><p>{step.text}</p></div>
            </article>
          ))}
        </div>
      </section>

      <section className="service-audience-section">
        <div>
          <small>CE SERVICE EST ADAPTÉ AUX</small>
          <h2>{service.forWho.join(" · ")}</h2>
        </div>
        <div className="service-outcomes-list">
          {service.outcomes.map((outcome) => <p key={outcome}><Check />{outcome}</p>)}
        </div>
      </section>

      <section className="product-final-cta service-final-cta">
        <div><small>SERVICE {service.number} · {service.title.toUpperCase()}</small><h2>Parlons de votre projet.</h2></div>
        <div>
          <Link href="/#devis">Configurer mon devis <ArrowRight /></Link>
          <a href="mailto:contact@onways.tech">Échanger avec OnwaysTech</a>
        </div>
      </section>
    </main>
  );
}
