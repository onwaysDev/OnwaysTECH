import ServiceDetail, { serviceConfigs } from "../ServiceDetail";

export default function SolutionsSaasPage() {
  return <ServiceDetail service={serviceConfigs["solutions-saas"]} />;
}
