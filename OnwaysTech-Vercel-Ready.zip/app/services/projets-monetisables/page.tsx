import ServiceDetail, { serviceConfigs } from "../ServiceDetail";

export default function ProjetsMonetisablesPage() {
  return <ServiceDetail service={serviceConfigs["projets-monetisables"]} />;
}
