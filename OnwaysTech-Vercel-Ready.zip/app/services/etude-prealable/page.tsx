import ServiceDetail, { serviceConfigs } from "../ServiceDetail";

export default function EtudePrealablePage() {
  return <ServiceDetail service={serviceConfigs["etude-prealable"]} />;
}
