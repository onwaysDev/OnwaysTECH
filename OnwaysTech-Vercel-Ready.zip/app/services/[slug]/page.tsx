import Link from "next/link";
import {
  ArrowLeft,
  ArrowRight,
  BarChart3,
  Blocks,
  CheckCircle2,
  ClipboardCheck,
  CloudCog,
  Code2,
  Compass,
  Eye,
  Gauge,
  Lightbulb,
  LineChart,
  ListChecks,
  MessageSquareText,
  MousePointerClick,
  Rocket,
  SearchCheck,
  ShieldCheck,
  Smartphone,
  Target,
  Users,
  Workflow,
  Wrench,
} from "lucide-react";

const servicePages = {
  "applications-utiles": {
    number: "01",
    title: "Applications utiles",
    kicker: "Une idée utile devient un outil simple",
    intro: "Nous concevons des applications web et mobiles performantes, pensées autour des usages réels de vos clients, équipes ou communautés.",
    problem: "Une tâche répétitive, un parcours trop compliqué ou un service encore manuel ralentit votre activité.",
    solution: "Nous transformons ce besoin concret en une application intuitive, fiable et prête à évoluer.",
    heroIcon: Smartphone,
    sceneIcons: [Users, MousePointerClick, Code2],
    steps: ["Comprendre les usages", "Dessiner le parcours", "Développer et tester", "Mettre en service"],
    deliverables: ["Parcours utilisateur", "Interface responsive", "Application fonctionnelle", "Tests et accompagnement"],
    benefits: ["Simple à utiliser", "Adaptée au terrain", "Évolutive", "Mesurable"],
    accent: "apps",
  },
  "audit-strategie-digitale": {
    number: "02",
    title: "Audit et stratégie digitale",
    kicker: "Voir clairement avant d’avancer",
    intro: "Nous analysons votre présence numérique, vos outils et votre organisation afin de révéler les points faibles et les meilleures opportunités.",
    problem: "Vous investissez dans le numérique sans savoir précisément ce qui fonctionne, ce qui bloque ou ce qu’il faut prioriser.",
    solution: "Notre audit transforme les constats en feuille de route claire, réaliste et directement exploitable.",
    heroIcon: SearchCheck,
    sceneIcons: [Eye, BarChart3, Compass],
    steps: ["Observer l’existant", "Mesurer les écarts", "Définir les priorités", "Tracer la stratégie"],
    deliverables: ["Diagnostic complet", "Analyse des risques", "Recommandations", "Plan d’action priorisé"],
    benefits: ["Décisions éclairées", "Budget mieux orienté", "Risques réduits", "Vision partagée"],
    accent: "audit",
  },
  "solutions-saas": {
    number: "03",
    title: "Création de solutions SaaS",
    kicker: "Construire une plateforme qui grandit",
    intro: "Nous concevons des plateformes accessibles en ligne, capables de servir plusieurs utilisateurs et de générer des revenus récurrents.",
    problem: "Une bonne idée ne devient pas automatiquement un produit numérique fiable, vendable et capable de monter en charge.",
    solution: "Nous structurons le produit, l’expérience, la technologie et le modèle d’abonnement dans un même parcours.",
    heroIcon: CloudCog,
    sceneIcons: [Blocks, CloudCog, LineChart],
    steps: ["Cadrer le produit", "Prototyper l’expérience", "Construire le socle SaaS", "Préparer la croissance"],
    deliverables: ["Architecture produit", "Espace utilisateurs", "Administration", "Abonnements et suivi"],
    benefits: ["Revenus récurrents", "Accès en ligne", "Croissance maîtrisée", "Gestion centralisée"],
    accent: "saas",
  },
  "projets-monetisables": {
    number: "04",
    title: "Développement de projets monétisables",
    kicker: "Transformer l’idée en activité numérique",
    intro: "Nous structurons votre idée pour en faire un produit utile, commercialisable et soutenu par un modèle économique cohérent.",
    problem: "Votre concept est prometteur, mais l’offre, le public, les revenus et le chemin de lancement restent encore flous.",
    solution: "Nous réunissons stratégie, produit et exécution pour construire une solution que le marché peut comprendre et adopter.",
    heroIcon: Rocket,
    sceneIcons: [Lightbulb, Target, LineChart],
    steps: ["Qualifier l’idée", "Définir la valeur", "Construire le produit", "Organiser le lancement"],
    deliverables: ["Proposition de valeur", "Modèle économique", "MVP numérique", "Plan de commercialisation"],
    benefits: ["Offre plus claire", "Marché mieux ciblé", "Revenus structurés", "Lancement piloté"],
    accent: "money",
  },
  "pilotage-digital": {
    number: "05",
    title: "Pilotage digital",
    kicker: "Un projet coordonné du début à la fin",
    intro: "Nous organisons les équipes, les décisions, les délais et la qualité afin que votre projet progresse avec méthode jusqu’à sa mise en production.",
    problem: "Sans coordination centrale, les intervenants avancent séparément, les décisions tardent et les coûts deviennent difficiles à maîtriser.",
    solution: "Onways.Tech devient le point de pilotage qui aligne vision, métiers, design et développement.",
    heroIcon: Workflow,
    sceneIcons: [Users, Workflow, Gauge],
    steps: ["Planifier les étapes", "Coordonner les acteurs", "Contrôler la qualité", "Suivre la production"],
    deliverables: ["Planning opérationnel", "Suivi des tâches", "Comptes rendus", "Contrôle des livraisons"],
    benefits: ["Responsabilités claires", "Délais suivis", "Qualité contrôlée", "Décisions rapides"],
    accent: "pilot",
  },
  "etude-prealable": {
    number: "06",
    title: "Étude préalable du projet web",
    kicker: "Valider le projet avant d’investir",
    intro: "Nous étudions votre besoin, vos utilisateurs, les fonctionnalités, les contraintes, le budget et les délais avant le lancement du développement.",
    problem: "Commencer trop vite peut conduire à un budget irréaliste, des fonctions inutiles ou une solution techniquement fragile.",
    solution: "L’étude préalable transforme votre intention en cadre de réalisation précis et réduit les mauvaises surprises.",
    heroIcon: ClipboardCheck,
    sceneIcons: [MessageSquareText, ListChecks, ShieldCheck],
    steps: ["Recueillir le besoin", "Étudier la faisabilité", "Définir le périmètre", "Préparer la réalisation"],
    deliverables: ["Expression du besoin", "Fonctionnalités détaillées", "Estimation indicative", "Recommandations techniques"],
    benefits: ["Projet clarifié", "Budget anticipé", "Risques identifiés", "Base solide"],
    accent: "study",
  },
} as const;

type ServiceSlug = keyof typeof servicePages;

export function generateStaticParams() {
  return Object.keys(servicePages).map((slug) => ({ slug }));
}

export default async function ServicePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const service = servicePages[slug as ServiceSlug];
  if (!service) return null;

  const HeroIcon = service.heroIcon;
  const [FirstIcon, SecondIcon, ThirdIcon] = service.sceneIcons;
  const quoteHref = `/?service=${encodeURIComponent(service.title)}#devis`;

  return (
    <main className={`service-detail service-theme-${service.accent}`}>
      <header className="service-header">
        <Link className="service-brand" href="/#accueil">
          <span className="brand-mark" aria-hidden="true"><span /></span>
          <span className="brand-name">Onways<span>.tech</span></span>
        </Link>
        <nav aria-label="Navigation de la page service">
          <Link href="/#services"><ArrowLeft size={16} /> Tous les services</Link>
          <Link className="service-header-cta" href={quoteHref}>Demander un devis <ArrowRight size={16} /></Link>
        </nav>
      </header>

      <section className="service-hero">
        <div className="comic-dots" aria-hidden="true" />
        <div className="service-hero-copy">
          <p className="service-label"><span>{service.number}</span> Service Onways.Tech</p>
          <h1>{service.title}</h1>
          <p className="service-kicker">{service.kicker}</p>
          <p className="service-intro">{service.intro}</p>
          <div className="service-hero-actions">
            <Link href={quoteHref}>Démarrer ce projet <ArrowRight size={18} /></Link>
            <a href="#methode">Voir notre méthode</a>
          </div>
        </div>

        <div className="comic-stage" aria-label={`Illustration animée du service ${service.title}`}>
          <span className="comic-burst" aria-hidden="true">ACTION!</span>
          <span className="motion-line line-a" aria-hidden="true" />
          <span className="motion-line line-b" aria-hidden="true" />
          <article className="comic-window">
            <div className="comic-window-top"><i /><i /><i /><span>ONWAYS LAB</span></div>
            <div className="comic-window-body">
              <HeroIcon className="comic-main-icon" aria-hidden="true" />
              <div className="comic-ui-lines"><i /><i /><i /></div>
              <div className="comic-progress"><span /></div>
            </div>
          </article>
          <span className="comic-star star-a" aria-hidden="true">✦</span>
          <span className="comic-star star-b" aria-hidden="true">✦</span>
        </div>
      </section>

      <section className="service-story">
        <article className="story-panel story-problem">
          <span className="panel-tag">LE PROBLÈME</span>
          <div className="story-scene" aria-hidden="true">
            <FirstIcon />
            <span className="scribble">?</span>
            <i className="scene-shadow" />
          </div>
          <h2>Ce qui vous ralentit</h2>
          <p>{service.problem}</p>
        </article>
        <article className="story-panel story-transition" aria-hidden="true">
          <span>ONWAYS</span>
          <ArrowRight />
          <b>TRANSFORME</b>
        </article>
        <article className="story-panel story-solution">
          <span className="panel-tag">NOTRE RÉPONSE</span>
          <div className="story-scene" aria-hidden="true">
            <SecondIcon />
            <ThirdIcon className="mini-scene-icon" />
            <span className="success-pop">✓</span>
          </div>
          <h2>La solution Onways.Tech</h2>
          <p>{service.solution}</p>
        </article>
      </section>

      <section className="service-method" id="methode">
        <div className="service-section-title">
          <span>NOTRE MÉTHODE</span>
          <h2>De la réflexion<br />à la réalisation.</h2>
          <p>Quatre étapes claires, chacune illustrée et animée pour suivre la progression du projet.</p>
        </div>
        <div className="method-track">
          {service.steps.map((step, index) => {
            const icons = [MessageSquareText, Wrench, Code2, Rocket];
            const StepIcon = icons[index];
            return (
              <article key={step} style={{ "--step-delay": `${index * 120}ms` } as React.CSSProperties}>
                <span>{String(index + 1).padStart(2, "0")}</span>
                <div className="method-cartoon"><StepIcon /><i /><b>{index === 3 ? "GO!" : "…"}</b></div>
                <h3>{step}</h3>
              </article>
            );
          })}
        </div>
      </section>

      <section className="service-results">
        <div className="deliverables-card">
          <div className="results-illustration" aria-hidden="true">
            <ClipboardCheck />
            <span className="paper paper-one" />
            <span className="paper paper-two" />
            <span className="stamp">VALIDÉ</span>
          </div>
          <div>
            <span className="results-label">CE QUE VOUS RECEVEZ</span>
            <h2>Des livrables concrets.</h2>
            <ul>{service.deliverables.map((item) => <li key={item}><CheckCircle2 /> {item}</li>)}</ul>
          </div>
        </div>
        <div className="benefits-card">
          <div>
            <span className="results-label">CE QUE VOUS GAGNEZ</span>
            <h2>Un projet mieux maîtrisé.</h2>
            <div className="benefit-grid">
              {service.benefits.map((item, index) => <span key={item}><b>0{index + 1}</b>{item}</span>)}
            </div>
          </div>
          <div className="rocket-scene" aria-hidden="true"><Rocket /><i /><span>IMPACT</span></div>
        </div>
      </section>

      <section className="service-final">
        <div className="final-comic-mark" aria-hidden="true"><Target /><span>À VOUS !</span></div>
        <div>
          <span>PRÊT À PASSER À L’ACTION ?</span>
          <h2>Faisons avancer<br />votre projet.</h2>
          <p>Le configurateur reprendra automatiquement le service « {service.title} ».</p>
        </div>
        <Link href={quoteHref}>Configurer mon devis <ArrowRight /></Link>
      </section>

      <footer className="service-footer">
        <span>© 2026 Onways.Tech</span>
        <Link href="/#services">Tous les services</Link>
        <a href="mailto:contact@onways.tech">contact@onways.tech</a>
      </footer>
    </main>
  );
}
