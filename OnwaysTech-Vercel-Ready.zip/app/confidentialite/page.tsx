import LegalPage from "../legal/LegalPage";

export default function ConfidentialitePage() {
  return (
    <LegalPage
      eyebrow="PROTECTION DES DONNÉES"
      title="Politique de confidentialité"
      intro="Nous expliquons clairement quelles données peuvent être reçues par OnwaysTech, pourquoi elles sont utilisées et comment exercer vos droits."
      sections={[
        {
          title: "Responsable du traitement",
          paragraphs: [
            "OnwaysTech, entité technologique de l’écosystème WINTAX établie à Abidjan, Côte d’Ivoire, est responsable des traitements réalisés directement à travers ce site.",
            "Pour toute question relative à vos données personnelles, vous pouvez écrire à contact@onways.tech.",
          ],
        },
        {
          title: "Données concernées",
          paragraphs: ["Nous limitons la collecte aux informations utiles à votre demande."],
          items: [
            "identité et coordonnées communiquées volontairement ;",
            "informations décrivant votre entreprise, votre besoin ou votre projet ;",
            "contenu des échanges transmis par e-mail ;",
            "données techniques et journaux de sécurité éventuellement générés par l’hébergement.",
          ],
        },
        {
          title: "Finalités et utilisation",
          items: [
            "répondre à vos demandes de contact et de devis ;",
            "préparer une estimation et assurer le suivi commercial ;",
            "sécuriser, maintenir et améliorer le fonctionnement du site ;",
            "respecter les obligations légales applicables.",
          ],
        },
        {
          title: "Destinataires et conservation",
          paragraphs: [
            "Les données sont accessibles aux personnes habilitées d’OnwaysTech et, lorsque cela est nécessaire, à ses prestataires techniques soumis à des obligations de confidentialité.",
            "Elles sont conservées pendant la durée nécessaire au traitement de la demande, à la relation commerciale et aux obligations légales, puis supprimées ou archivées de manière sécurisée.",
          ],
        },
        {
          title: "Vos droits",
          paragraphs: [
            "Conformément à la loi ivoirienne n° 2013-450 du 19 juin 2013 relative à la protection des données à caractère personnel, vous pouvez demander l’accès, la rectification, l’opposition ou la suppression de vos données lorsque les conditions légales sont réunies.",
            "Adressez votre demande à contact@onways.tech en précisant son objet. Vous pouvez également saisir l’Autorité de protection des données personnelles de Côte d’Ivoire.",
          ],
        },
        {
          title: "Sécurité et évolution",
          paragraphs: [
            "OnwaysTech applique des mesures raisonnables de protection contre l’accès non autorisé, la perte, l’altération ou la divulgation des données.",
            "Cette politique peut évoluer pour tenir compte des services proposés ou d’un changement réglementaire. La date affichée en haut de page identifie la version applicable.",
          ],
        },
      ]}
    />
  );
}
