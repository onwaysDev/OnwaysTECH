import LegalPage from "../legal/LegalPage";

export default function CookiesPage() {
  return (
    <LegalPage
      eyebrow="GESTION DES TRACEURS"
      title="Politique relative aux cookies"
      intro="Cette page explique les technologies susceptibles d’être utilisées pour faire fonctionner, sécuriser et mesurer le site."
      sections={[
        {
          title: "Qu’est-ce qu’un cookie ?",
          paragraphs: [
            "Un cookie est un petit fichier ou identifiant enregistré sur votre appareil lors de la consultation d’un site. Il peut mémoriser une préférence, maintenir une fonction essentielle ou aider à comprendre l’utilisation du service.",
          ],
        },
        {
          title: "Cookies actuellement utilisés",
          paragraphs: [
            "Le site privilégie les traceurs strictement nécessaires à son fonctionnement, à sa sécurité et, lorsqu’une authentification est requise, au maintien de la session. Ces traceurs ne servent pas à établir un profil publicitaire.",
          ],
        },
        {
          title: "Mesure d’audience et services tiers",
          paragraphs: [
            "Si un outil de mesure d’audience, une vidéo intégrée ou un autre service non essentiel est ajouté ultérieurement, son utilisation sera indiquée et, lorsque la loi l’exige, soumise à votre choix avant dépôt.",
          ],
        },
        {
          title: "Gérer vos préférences",
          paragraphs: [
            "Vous pouvez configurer votre navigateur pour bloquer ou supprimer les cookies. Le refus des cookies strictement nécessaires peut toutefois empêcher certaines fonctions de fonctionner correctement.",
            "Une interface de préférences sera proposée si le site active des catégories de traceurs optionnels.",
          ],
        },
        {
          title: "Durée et contact",
          paragraphs: [
            "Les traceurs sont conservés uniquement pendant la durée nécessaire à leur finalité et selon les paramètres du service concerné. Pour toute question sur les cookies utilisés par OnwaysTech : contact@onways.tech.",
          ],
        },
      ]}
    />
  );
}
