import LegalPage from "../legal/LegalPage";

export default function MentionsLegalesPage() {
  return (
    <LegalPage
      eyebrow="INFORMATIONS ÉDITEUR"
      title="Mentions légales"
      intro="Les informations essentielles relatives à l’édition, à l’exploitation et à l’utilisation du site Onways.Tech."
      sections={[
        {
          title: "Éditeur du site",
          paragraphs: [
            "Le présent site est édité par OnwaysTech, entité technologique de l’écosystème WINTAX, établie à Abidjan, Côte d’Ivoire.",
            "Contact : contact@onways.tech. Le responsable de la publication est la direction d’OnwaysTech.",
          ],
        },
        {
          title: "Objet du site",
          paragraphs: [
            "Onways.Tech présente les services, produits numériques et expertises d’OnwaysTech. Les informations publiées ont une finalité générale et commerciale ; elles ne constituent pas, à elles seules, une offre contractuelle ferme.",
          ],
        },
        {
          title: "Hébergement",
          paragraphs: [
            "Le site est déployé sur l’infrastructure ChatGPT Sites d’OpenAI. Des prestataires techniques peuvent intervenir pour assurer l’hébergement, la disponibilité, la sécurité et la diffusion du service.",
          ],
        },
        {
          title: "Propriété intellectuelle",
          paragraphs: [
            "La structure du site, les textes, créations graphiques, marques, noms de produits, logos et éléments visuels sont protégés. Sauf autorisation écrite, toute reproduction, adaptation, extraction ou exploitation commerciale, totale ou partielle, est interdite.",
            "Les marques ou logos de tiers demeurent la propriété de leurs titulaires respectifs.",
          ],
        },
        {
          title: "Responsabilité",
          paragraphs: [
            "OnwaysTech veille à fournir des informations utiles et à maintenir le site accessible. Des erreurs, interruptions ou changements peuvent toutefois survenir. L’utilisateur reste responsable de ses décisions et de la protection de son équipement.",
            "Les liens vers des services externes sont fournis à titre pratique ; OnwaysTech ne contrôle pas leur contenu ni leurs politiques.",
          ],
        },
        {
          title: "Droit applicable",
          paragraphs: [
            "Le site et les présentes mentions sont régis par le droit ivoirien. Les parties rechercheront d’abord une solution amiable avant toute procédure devant la juridiction compétente.",
          ],
        },
      ]}
    />
  );
}
