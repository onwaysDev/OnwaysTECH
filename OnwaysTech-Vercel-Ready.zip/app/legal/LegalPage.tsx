import Link from "next/link";

type Section = {
  title: string;
  paragraphs?: string[];
  items?: string[];
};

type LegalPageProps = {
  eyebrow: string;
  title: string;
  intro: string;
  updated?: string;
  sections: Section[];
};

export default function LegalPage({
  eyebrow,
  title,
  intro,
  updated = "30 juillet 2026",
  sections,
}: LegalPageProps) {
  return (
    <main className="legal-page">
      <header className="legal-header">
        <Link className="legal-brand" href="/#accueil" aria-label="Retour à l’accueil OnwaysTech">
          <span className="brand-mark" aria-hidden="true"><span /></span>
          <span className="brand-name">Onways<span>.tech</span></span>
        </Link>
        <Link className="legal-back" href="/#accueil">← Retour au site</Link>
      </header>

      <section className="legal-hero">
        <p>{eyebrow}</p>
        <h1>{title}</h1>
        <span />
        <p>{intro}</p>
        <small>Dernière mise à jour : {updated}</small>
      </section>

      <div className="legal-layout">
        <aside>
          <strong>OnwaysTech</strong>
          <span>Abidjan · Côte d’Ivoire</span>
          <a href="mailto:contact@onways.tech">contact@onways.tech</a>
        </aside>

        <article className="legal-content">
          {sections.map((section, index) => (
            <section key={section.title}>
              <span className="legal-number">{String(index + 1).padStart(2, "0")}</span>
              <div>
                <h2>{section.title}</h2>
                {section.paragraphs?.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}
                {section.items && (
                  <ul>
                    {section.items.map((item) => <li key={item}>{item}</li>)}
                  </ul>
                )}
              </div>
            </section>
          ))}
        </article>
      </div>

      <footer className="legal-footer">
        <span>© 2026 OnwaysTech</span>
        <nav aria-label="Pages juridiques">
          <Link href="/confidentialite">Confidentialité</Link>
          <Link href="/mentions-legales">Mentions légales</Link>
          <Link href="/conditions-utilisation">Conditions</Link>
          <Link href="/cookies">Cookies</Link>
        </nav>
      </footer>
    </main>
  );
}
