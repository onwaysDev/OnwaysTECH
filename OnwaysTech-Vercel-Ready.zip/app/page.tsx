"use client";

import { useEffect, useRef, useState } from "react";
import {
  BarChart3,
  Blocks,
  Braces,
  Brush,
  Code2,
  Compass,
  ClipboardCheck,
  CloudCog,
  CreditCard,
  Database,
  Figma,
  Gauge,
  GitBranch,
  Handshake,
  KanbanSquare,
  LockKeyhole,
  Megaphone,
  MousePointerClick,
  Network,
  PanelTop,
  SearchCheck,
  ShieldCheck,
  Smartphone,
  Sparkles,
  TrendingUp,
  Workflow,
  X,
} from "lucide-react";

const teamMembers = [
  { portrait:"/assets/team/fatim-koffi.png", name:"Fatim Koffi", role:"CEO adjointe", detail:"WINTAX", icon:Compass },
  { portrait:"/assets/team/sosthene-frondo.png", name:"M. Sosthène Frondo", role:"Expert informaticien", detail:"Chef de projet", icon:Network },
  { portrait:"/assets/team/yasmine-frondo.png", name:"Mme Yasmine Frondo", role:"Chargée des études", detail:"de projets", icon:ClipboardCheck },
  { portrait:"/assets/team/divine-ouattara-yao.png", name:"Mme Divine Ouattara-Yao", role:"Chargée de conformité", detail:"", icon:ShieldCheck },
  { portrait:"/assets/team/serge-alain-ahondjon.png", name:"Serge Alain Ahondjon", role:"Développeur", detail:"", icon:Code2 },
  { portrait:"/assets/team/andrea-koffi.png", name:"Mlle Andrea Koffi", role:"Marketing", detail:"et publicité", icon:Megaphone },
  { portrait:"/assets/team/suzanne-kobi.png", name:"Mme Suzanne Kobi-Laubo", role:"Chargée des affaires", detail:"extérieures", icon:Handshake },
  { portrait:"/assets/team/marie-pascale.png", name:"Mlle Ossohou Marie Pascale", role:"Expérience utilisateur", detail:"", icon:MousePointerClick },
] as const;

const teamTools = [
  { name:"Figma", icon:Figma },
  { name:"GitHub", icon:GitBranch },
  { name:"Visual Studio Code", icon:Code2 },
  { name:"React", icon:Blocks },
  { name:"Next.js", icon:PanelTop },
  { name:"TypeScript", icon:Braces },
  { name:"Supabase", icon:Database },
  { name:"OpenAI", icon:Sparkles },
  { name:"Vercel", icon:Gauge },
  { name:"Canva", icon:Brush },
  { name:"Google Analytics", icon:BarChart3 },
  { name:"Gestion de projet", icon:KanbanSquare },
  { name:"Cybersécurité", icon:LockKeyhole },
  { name:"Paiement & API", icon:CreditCard },
] as const;

const services = [
  {
    slug: "applications-utiles",
    number: "01",
    title: "Applications utiles",
    text: "Développement d’applications web et mobiles simples, performantes et adaptées aux besoins réels des utilisateurs.",
    icon: <Smartphone aria-hidden="true" />,
    price: 1500000,
  },
  {
    slug: "audit-strategie-digitale",
    number: "02",
    title: "Audit et stratégie digitale",
    text: "Analyse du projet, identification des faiblesses et proposition d’une stratégie numérique avec des recommandations concrètes.",
    icon: <SearchCheck aria-hidden="true" />,
    price: 300000,
  },
  {
    slug: "solutions-saas",
    number: "03",
    title: "Création de solutions SaaS",
    text: "Conception de plateformes numériques accessibles en ligne, évolutives et capables de générer des revenus récurrents.",
    icon: <CloudCog aria-hidden="true" />,
    price: 3000000,
  },
  {
    slug: "projets-monetisables",
    number: "04",
    title: "Développement de projets monétisables",
    text: "Transformation d’une idée en produit numérique structuré, commercialisable et doté d’un modèle économique viable.",
    icon: <TrendingUp aria-hidden="true" />,
    price: 2500000,
  },
  {
    slug: "pilotage-digital",
    number: "05",
    title: "Pilotage digital",
    text: "Organisation, coordination et suivi complet du projet, depuis sa conception jusqu’à sa mise en production.",
    icon: <Workflow aria-hidden="true" />,
    price: 750000,
  },
  {
    slug: "etude-prealable",
    number: "06",
    title: "Étude préalable du projet web",
    text: "Étude de faisabilité : besoins, fonctionnalités, utilisateurs, contraintes techniques, budget, délais et recommandations.",
    icon: <ClipboardCheck aria-hidden="true" />,
    price: 250000,
  },
];

const quoteFeatures = [
  ["Authentification", 150000],
  ["Paiement en ligne", 300000],
  ["Back-office", 350000],
  ["SEO avancé", 100000],
  ["Sécurité renforcée", 200000],
  ["Analytics", 125000],
  ["Intégrations API", 500000],
  ["Notifications", 150000],
] as const;

const quoteDelivery = [
  ["Identité visuelle", 250000],
  ["Création de contenus", 200000],
  ["Tests & recette", 150000],
  ["Maintenance 3 mois", 300000],
  ["Formation", 150000],
  ["Hébergement & domaine", 100000],
] as const;

const formatFcfa = (value: number) =>
  `${new Intl.NumberFormat("fr-FR").format(value)} FCFA`;

export default function Home() {
  const panelsRef = useRef<HTMLDivElement>(null);
  const navRef = useRef<HTMLElement>(null);
  const footerRef = useRef<HTMLElement>(null);
  const teamRef = useRef<HTMLElement>(null);
  const toolsMarqueeRef = useRef<HTMLDivElement>(null);
  const toolDragRef = useRef({ active:false, x:0, scrollLeft:0 });
  const [activePanel, setActivePanel] = useState("accueil");
  const [navIndicator, setNavIndicator] = useState({ left: 0, width: 0 });
  const [selectedService, setSelectedService] = useState(() => {
    if (typeof window === "undefined") return "Applications utiles";
    const requestedService = new URLSearchParams(window.location.search).get("service");
    return requestedService && services.some((service) => service.title === requestedService)
      ? requestedService
      : "Applications utiles";
  });
  const [quoteStep, setQuoteStep] = useState(1);
  const [selectedFeatures, setSelectedFeatures] = useState<string[]>([]);
  const [selectedDelivery, setSelectedDelivery] = useState<string[]>([]);
  const [footerActive, setFooterActive] = useState(false);
  const [teamActive, setTeamActive] = useState(false);
  const [selectedMember, setSelectedMember] = useState<(typeof teamMembers)[number] | null>(null);
  const [toolsPaused, setToolsPaused] = useState(false);

  const navigateToPanel = (id: string) => {
    const panels = panelsRef.current;
    const target = document.getElementById(id);
    if (!panels || !target) return;

    if (window.matchMedia("(max-width: 800px)").matches) {
      target.scrollIntoView({ behavior: "smooth", block: "start" });
    } else {
      panels.scrollTo({ left: target.offsetLeft, behavior: "smooth" });
    }
    setActivePanel(id);
    window.history.replaceState(null, "", `#${id}`);
  };

  useEffect(() => {
    const panels = panelsRef.current;
    if (!panels) return;

    let animationFrame = 0;
    const syncActivePanel = () => {
      cancelAnimationFrame(animationFrame);
      animationFrame = requestAnimationFrame(() => {
        const pages = Array.from(panels.querySelectorAll<HTMLElement>(":scope > .panel"));
        const isVertical = window.matchMedia("(max-width: 800px)").matches;
        const visiblePage = isVertical
          ? pages
              .map((page) => ({ page, distance: Math.abs(page.getBoundingClientRect().top - window.innerHeight * .22) }))
              .sort((a, b) => a.distance - b.distance)[0]?.page
          : pages.find((page) => {
              const center = panels.scrollLeft + panels.clientWidth / 2;
              return center >= page.offsetLeft && center < page.offsetLeft + page.offsetWidth;
            });
        if (visiblePage?.id) {
          setActivePanel(visiblePage.id);
          window.history.replaceState(null, "", `#${visiblePage.id}`);
        }
      });
    };

    syncActivePanel();
    panels.addEventListener("scroll", syncActivePanel, { passive: true });
    window.addEventListener("scroll", syncActivePanel, { passive: true });
    window.addEventListener("resize", syncActivePanel);
    return () => {
      cancelAnimationFrame(animationFrame);
      panels.removeEventListener("scroll", syncActivePanel);
      window.removeEventListener("scroll", syncActivePanel);
      window.removeEventListener("resize", syncActivePanel);
    };
  }, []);

  useEffect(() => {
    const requestedPanel = window.location.hash.slice(1);
    if (!requestedPanel) return;
    const frame = requestAnimationFrame(() => navigateToPanel(requestedPanel));
    return () => cancelAnimationFrame(frame);
  // The initial fragment is intentionally handled once after the panels mount.
  }, []);

  useEffect(() => {
    const nav = navRef.current;
    if (!nav) return;

    const positionIndicator = () => {
      const activeLink = nav.querySelector<HTMLAnchorElement>(`a[href="#${activePanel}"]`);
      if (!activeLink) return;
      setNavIndicator({
        left: activeLink.offsetLeft,
        width: activeLink.offsetWidth,
      });
    };

    positionIndicator();
    window.addEventListener("resize", positionIndicator);
    return () => window.removeEventListener("resize", positionIndicator);
  }, [activePanel]);

  useEffect(() => {
    const footer = footerRef.current;
    if (!footer) return;
    const observer = new IntersectionObserver(
      ([entry]) => setFooterActive(entry.isIntersecting),
      { threshold: 0.35 },
    );
    observer.observe(footer);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const team = teamRef.current;
    if (!team) return;
    const observer = new IntersectionObserver(
      ([entry]) => setTeamActive(entry.isIntersecting),
      { threshold: 0.35 },
    );
    observer.observe(team);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const marquee = toolsMarqueeRef.current;
    if (!marquee || !teamActive || toolsPaused || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    let frame = 0;
    let previous = performance.now();
    const move = (now: number) => {
      const elapsed = Math.min(32, now - previous);
      previous = now;
      marquee.scrollLeft += elapsed * .026;
      const loopWidth = marquee.scrollWidth / 2;
      if (loopWidth && marquee.scrollLeft >= loopWidth) marquee.scrollLeft -= loopWidth;
      frame = requestAnimationFrame(move);
    };
    frame = requestAnimationFrame(move);
    return () => cancelAnimationFrame(frame);
  }, [teamActive, toolsPaused]);

  useEffect(() => {
    if (!selectedMember) return;
    const close = (event: KeyboardEvent) => {
      if (event.key === "Escape") setSelectedMember(null);
    };
    window.addEventListener("keydown", close);
    return () => window.removeEventListener("keydown", close);
  }, [selectedMember]);

  useEffect(() => {
    const handleDirectionalKeys = (event: KeyboardEvent) => {
      if (
        event.defaultPrevented ||
        event.repeat ||
        event.altKey ||
        event.ctrlKey ||
        event.metaKey
      ) return;

      const target = event.target as HTMLElement | null;
      if (
        target?.isContentEditable ||
        target?.closest("input, textarea, select, button, [contenteditable='true']")
      ) return;

      const isPrevious = event.key === "ArrowLeft" || event.key === "ArrowUp";
      const isNext = event.key === "ArrowRight" || event.key === "ArrowDown";
      if (!isPrevious && !isNext && event.key !== "Home" && event.key !== "End") return;

      const panels = panelsRef.current;
      if (!panels) return;
      event.preventDefault();

      if (window.matchMedia("(max-width: 800px)").matches) {
        const direction = isPrevious ? -1 : 1;
        if (event.key === "Home") window.scrollTo({ top: 0, behavior: "smooth" });
        else if (event.key === "End") window.scrollTo({ top: document.body.scrollHeight, behavior: "smooth" });
        else window.scrollBy({ top: direction * window.innerHeight * .88, behavior: "smooth" });
        return;
      }

      const pages = Array.from(panels.querySelectorAll<HTMLElement>(":scope > .panel"));
      const width = panels.clientWidth || window.innerWidth;
      const current = Math.round(panels.scrollLeft / width);
      const destination = event.key === "Home"
        ? 0
        : event.key === "End"
          ? pages.length - 1
          : Math.max(0, Math.min(pages.length - 1, current + (isPrevious ? -1 : 1)));
      const page = pages[destination];

      panels.scrollTo({ left: page?.offsetLeft ?? destination * width, behavior: "smooth" });
      if (page?.id) window.history.replaceState(null, "", `#${page.id}`);
    };

    window.addEventListener("keydown", handleDirectionalKeys);
    return () => window.removeEventListener("keydown", handleDirectionalKeys);
  }, []);

  const toggleQuoteItem = (
    item: string,
    setter: React.Dispatch<React.SetStateAction<string[]>>,
  ) => setter((current) => current.includes(item) ? current.filter((value) => value !== item) : [...current, item]);

  const servicePrice = services.find((service) => service.title === selectedService)?.price ?? 0;
  const extrasPrice = [...quoteFeatures, ...quoteDelivery]
    .filter(([name]) => selectedFeatures.includes(name) || selectedDelivery.includes(name))
    .reduce((total, [, price]) => total + price, 0);
  const quoteTotal = servicePrice + extrasPrice;
  const quoteMail = `mailto:contact@onways.tech?subject=${encodeURIComponent(`Demande de devis — ${selectedService}`)}&body=${encodeURIComponent(`Service : ${selectedService}\nFonctionnalités : ${selectedFeatures.join(", ") || "À préciser"}\nAccompagnement : ${selectedDelivery.join(", ") || "À préciser"}\nEstimation préliminaire : ${formatFcfa(quoteTotal)}`)}`;

  const moveHorizontally = (event: React.WheelEvent<HTMLDivElement>) => {
    if (!panelsRef.current || Math.abs(event.deltaY) <= Math.abs(event.deltaX)) return;
    event.preventDefault();
    panelsRef.current.scrollBy({ left: event.deltaY, behavior: "smooth" });
  };

  return (
    <main className="horizontal-site">
      <header className="site-header">
        <a className="brand" href="#accueil" aria-label="OnwaysTech, accueil">
          <span className="brand-mark" aria-hidden="true">
            <span />
          </span>
          <span className="brand-name">
            Onways<span>.tech</span>
          </span>
        </a>

        <nav ref={navRef} aria-label="Navigation principale">
          <span
            className="nav-indicator"
            aria-hidden="true"
            style={{ width: navIndicator.width, transform: `translateX(${navIndicator.left}px)` }}
          />
          <a className={activePanel === "accueil" ? "active" : ""} onClick={(event) => { event.preventDefault(); navigateToPanel("accueil"); }} href="#accueil">Accueil</a>
          <a className={activePanel === "produits" ? "active" : ""} onClick={(event) => { event.preventDefault(); navigateToPanel("produits"); }} href="#produits">Produits <small>⌄</small></a>
          <a className={activePanel === "services" ? "active" : ""} onClick={(event) => { event.preventDefault(); navigateToPanel("services"); }} href="#services">Services <small>⌄</small></a>
          <a className={activePanel === "devis" ? "active" : ""} onClick={(event) => { event.preventDefault(); navigateToPanel("devis"); }} href="#devis">Devis</a>
          <a className={activePanel === "apropos" ? "active" : ""} onClick={(event) => { event.preventDefault(); navigateToPanel("apropos"); }} href="#apropos">À propos</a>
          <a className={activePanel === "equipe" ? "active" : ""} onClick={(event) => { event.preventDefault(); navigateToPanel("equipe"); }} href="#equipe">Équipe</a>
          <a className={activePanel === "ecosysteme" ? "active" : ""} onClick={(event) => { event.preventDefault(); navigateToPanel("ecosysteme"); }} href="#ecosysteme">Écosystème</a>
        </nav>

        <a className="contact-button" href="#contact">
          <span aria-hidden="true">✉</span> Contact
        </a>
      </header>

      <div
        className="horizontal-panels"
        ref={panelsRef}
        onWheel={moveHorizontally}
        aria-label="Pages horizontales OnwaysTech"
      >
      <section className="hero panel" id="accueil">
        <div className="hero-grid" aria-hidden="true" />
        <div className="hero-copy">
          <p className="eyebrow"><span /> Studio de solutions numériques</p>
          <h1>
            Construire l’utile.
            <em>Créer l’impact.</em>
          </h1>
          <p className="hero-lead">
            Nous imaginons des produits numériques simples, intelligents et
            capables de faire grandir vos ambitions.
          </p>
          <div className="hero-actions">
            <a className="primary-button" href="#produits">
              Explorer nos produits <span>↗</span>
            </a>
            <a className="text-link" href="#services">Découvrir notre expertise <span>→</span></a>
          </div>
          <div className="trust-line">
            <span>Stratégie</span><i />
            <span>Design</span><i />
            <span>Technologie</span>
          </div>
        </div>

        <div className="hero-visual" aria-label="Aperçu des produits OnwaysTech">
          <div className="orb orb-one" />
          <div className="orb orb-two" />
          <div className="orbit orbit-one" />
          <div className="orbit orbit-two" />

          <div className="dashboard-card">
            <div className="dash-sidebar">
              <b>O.</b>
              <span className="selected" />
              <span />
              <span />
              <span />
            </div>
            <div className="dash-content">
              <div className="dash-top">
                <div>
                  <small>ESPACE ONWAYS</small>
                  <h2>Bonjour, Alex.</h2>
                </div>
                <span className="avatar">AX</span>
              </div>
              <p>Que souhaitez-vous accomplir aujourd’hui ?</p>
              <div className="search-bar"><span>Décrivez votre projet…</span><b>↗</b></div>
              <div className="dash-stat-row">
                <article><span>PRODUITS</span><strong>03</strong><i>+1</i></article>
                <article><span>PROJETS</span><strong>12</strong><i>↗</i></article>
                <article><span>IMPACT</span><strong>∞</strong><i>◎</i></article>
              </div>
            </div>
          </div>

          <article className="product-card speakf-card">
            <div className="product-logo">SF</div>
            <div><b>SPeaKF</b><span>Votre intelligence financière</span></div>
          </article>

          <article className="product-card newister-card">
            <div className="product-logo cross">✦</div>
            <div><b>NeWisTer</b><span>La technologie au service de DIEU</span></div>
          </article>

          <article className="product-card onwayspay-card">
            <div className="product-logo pay">OP</div>
            <div><b>OnwaysPay</b><span>Vos services numériques simplifiés</span></div>
          </article>

          <div className="phone-card">
            <div className="phone-speaker" />
            <div className="phone-head">
              <span className="mini-mark">O</span>
              <small>OnwaysPay</small>
            </div>
            <h3>Tout échanger.<br />En un geste.</h3>
            <div className="money-row"><b>MTN</b><span>⇄</span><b className="wave">wave</b></div>
            <div className="phone-action">Échanger maintenant <span>→</span></div>
          </div>
          <p className="visual-caption">UN ÉCOSYSTÈME.<br /><b>PLUSIEURS POSSIBILITÉS.</b></p>
        </div>
      </section>

      <section className={`products-page panel${activePanel === "produits" ? " products-active" : ""}`} id="produits">
        <div className="products-ambient" aria-hidden="true">
          <span className="ambient-ring ring-one" />
          <span className="ambient-ring ring-two" />
          <span className="ambient-beam" />
          <span className="ambient-spark spark-one" />
          <span className="ambient-spark spark-two" />
          <span className="ambient-spark spark-three" />
        </div>
        <div className="products-intro">
          <span className="intro-rule"><i /></span>
          <p className="products-kicker">L’ÉCOSYSTÈME ONWAYS.TECH</p>
          <span className="intro-gold-line" />
        </div>

        <div className="product-doors" aria-label="Les produits OnwaysTech">
          <span className="products-flow-line" aria-hidden="true"><i /></span>
          <article className="door-card door-pay">
            <span className="door-number">01</span>
            <span className="door-category">SERVICES NUMÉRIQUES</span>
            <div className="product-brand-lockup">
              <img
                className="official-product-logo"
                src="/assets/products/onwayspay-logo.png"
                alt="OnwaysPay"
              />
            </div>
            <p>Services numériques simplifiés.</p>
            <a href="/produits/onwayspay" aria-label="Découvrir OnwaysPay">Découvrir <span>→</span></a>
          </article>

          <article className="door-card door-speak">
            <span className="door-number">02</span>
            <span className="door-category">INTELLIGENCE FINANCIÈRE</span>
            <div className="product-brand-lockup">
              <img
                className="official-product-logo"
                src="/assets/products/speakf-logo.png"
                alt="SPeaKF"
              />
            </div>
            <p>L’intelligence financière pour mieux décider.</p>
            <a href="/produits/speakf" aria-label="Découvrir SPeaKF">Découvrir <span>→</span></a>
          </article>

          <article className="door-card door-newister">
            <span className="door-number">03</span>
            <span className="door-category">TECHNOLOGIE BIBLIQUE</span>
            <div className="product-brand-lockup">
              <img
                className="official-product-logo"
                src="/assets/products/newister-logo.png"
                alt="NeWisTer"
              />
            </div>
            <p>La technologie au service de DIEU.</p>
            <a href="/produits/newister" aria-label="Découvrir NeWisTer">Découvrir <span>→</span></a>
          </article>
        </div>
      </section>

      <section className="services-strip panel" id="services">
        <div className="section-heading">
          <p className="eyebrow"><span /> Notre expertise</p>
          <h2>Six expertises.<br /><em>Un seul partenaire.</em></h2>
          <p>Nous structurons, concevons et pilotons les solutions numériques qui font avancer votre organisation.</p>
        </div>
        <div className="service-grid">
          {services.map((service, index) => (
            <article key={service.number} className={`service-motion service-motion-${index + 1}`}>
              <span className="service-number">{service.number}</span>
              <div className="service-cartoon" aria-hidden="true">
                <span className="cartoon-spark">✦</span>
                <span className="cartoon-screen">{service.icon}</span>
                <span className="cartoon-action">
                  <i /><i /><i />
                </span>
                <span className="cartoon-ground" />
              </div>
              <h3>{service.title}</h3>
              <p>{service.text}</p>
              <a href={`/services/${service.slug}`} aria-label={`Découvrir ${service.title}`}>↗</a>
            </article>
          ))}
        </div>
      </section>

      <section className="quote-page panel" id="devis">
        <div className="quote-copy">
          <p className="eyebrow"><span /> Configurateur de projet</p>
          <h2>Votre besoin.<br /><em>Votre devis.</em></h2>
          <p>Complétez les cinq niveaux et obtenez immédiatement une estimation préliminaire de votre projet.</p>
          <div className="quote-progress">
            {["Service", "Projet", "Fonctions", "Livraison", "Récap"].map((label, index) => (
              <button
                type="button"
                key={label}
                className={quoteStep === index + 1 ? "active" : quoteStep > index + 1 ? "done" : ""}
                onClick={() => setQuoteStep(index + 1)}
              >
                <b>{String(index + 1).padStart(2, "0")}</b><span>{label}</span>
              </button>
            ))}
          </div>
          <div className="live-estimate">
            <small>ESTIMATION ACTUELLE</small>
            <strong>{formatFcfa(quoteTotal)}</strong>
            <span>Estimation indicative, hors besoins spécifiques.</span>
          </div>
        </div>
        <div className="quote-card">
          <div className="quote-card-head">
            <span>ÉTAPE {String(quoteStep).padStart(2, "0")} / 05</span>
            <b>{[
              "Choisissez votre service",
              "Présentez votre projet",
              "Ajoutez vos fonctionnalités",
              "Choisissez l’accompagnement",
              "Vérifiez votre estimation",
            ][quoteStep - 1]}</b>
          </div>

          {quoteStep === 1 && (
            <div className="quote-options quote-service-options">
              {services.map((service) => (
                <button
                  key={service.number}
                  type="button"
                  className={selectedService === service.title ? "selected" : ""}
                  onClick={() => setSelectedService(service.title)}
                >
                  <i>{service.icon}</i>
                  <span>{service.title}<small>À partir de {formatFcfa(service.price)}</small></span>
                  <b>{selectedService === service.title ? "✓" : "→"}</b>
                </button>
              ))}
            </div>
          )}

          {quoteStep === 2 && (
            <div className="project-fields">
              <label><span>Nom du projet</span><input placeholder="Ex. Plateforme de réservation" /></label>
              <label><span>Type de client</span><select defaultValue=""><option value="" disabled>Choisir</option><option>Entreprise</option><option>Entrepreneur</option><option>Organisation</option><option>Église / Ministère</option></select></label>
              <label className="wide"><span>Description du besoin</span><textarea placeholder="Décrivez votre idée, vos objectifs et votre public cible…" /></label>
              <label><span>Budget envisagé</span><select defaultValue=""><option value="" disabled>Choisir</option><option>Moins de 500 000 FCFA</option><option>500 000 – 1 500 000 FCFA</option><option>1 500 000 – 5 000 000 FCFA</option><option>Plus de 5 000 000 FCFA</option></select></label>
              <label><span>Délai souhaité</span><select defaultValue=""><option value="" disabled>Choisir</option><option>Moins d’un mois</option><option>1 à 3 mois</option><option>3 à 6 mois</option><option>Plus de 6 mois</option></select></label>
            </div>
          )}

          {quoteStep === 3 && (
            <div className="priced-options">
              {quoteFeatures.map(([name, price]) => (
                <button type="button" key={name} className={selectedFeatures.includes(name) ? "selected" : ""} onClick={() => toggleQuoteItem(name, setSelectedFeatures)}>
                  <span><i>{selectedFeatures.includes(name) ? "✓" : "+"}</i><b>{name}</b></span><small>+ {formatFcfa(price)}</small>
                </button>
              ))}
            </div>
          )}

          {quoteStep === 4 && (
            <div className="priced-options delivery-options">
              {quoteDelivery.map(([name, price]) => (
                <button type="button" key={name} className={selectedDelivery.includes(name) ? "selected" : ""} onClick={() => toggleQuoteItem(name, setSelectedDelivery)}>
                  <span><i>{selectedDelivery.includes(name) ? "✓" : "+"}</i><b>{name}</b></span><small>+ {formatFcfa(price)}</small>
                </button>
              ))}
            </div>
          )}

          {quoteStep === 5 && (
            <div className="quote-summary">
              <div className="summary-lines">
                <p><span>Service</span><b>{selectedService}</b><small>{formatFcfa(servicePrice)}</small></p>
                <p><span>Fonctionnalités</span><b>{selectedFeatures.length || "Aucune"}</b><small>{formatFcfa(quoteFeatures.filter(([name]) => selectedFeatures.includes(name)).reduce((sum, [, price]) => sum + price, 0))}</small></p>
                <p><span>Accompagnement</span><b>{selectedDelivery.length || "Aucun"}</b><small>{formatFcfa(quoteDelivery.filter(([name]) => selectedDelivery.includes(name)).reduce((sum, [, price]) => sum + price, 0))}</small></p>
              </div>
              <div className="summary-total"><span>Estimation préliminaire</span><strong>{formatFcfa(quoteTotal)}</strong><small>Fourchette possible : {formatFcfa(quoteTotal)} – {formatFcfa(Math.round(quoteTotal * 1.2))}</small></div>
              <div className="contact-fields">
                <label><span className="sr-only">Nom et prénom</span><input name="name" autoComplete="name" placeholder="Nom et prénom" aria-label="Nom et prénom" /></label>
                <label><span className="sr-only">Adresse e-mail</span><input name="email" type="email" autoComplete="email" placeholder="Adresse e-mail" aria-label="Adresse e-mail" /></label>
                <label><span className="sr-only">Téléphone ou WhatsApp</span><input name="tel" type="tel" autoComplete="tel" placeholder="Téléphone / WhatsApp" aria-label="Téléphone ou WhatsApp" /></label>
              </div>
            </div>
          )}

          <div className="quote-footer">
            <button type="button" disabled={quoteStep === 1} onClick={() => setQuoteStep((step) => Math.max(1, step - 1))}>← Retour</button>
            <span>Niveau {quoteStep} sur 5</span>
            {quoteStep < 5 ? (
              <button type="button" className="next-step" onClick={() => setQuoteStep((step) => Math.min(5, step + 1))}>Continuer <b>→</b></button>
            ) : (
              <a href={quoteMail}>Envoyer la demande <b>→</b></a>
            )}
          </div>
        </div>
      </section>

      <section
        className={`about-page panel ${activePanel === "apropos" ? "about-active" : ""}`}
        id="apropos"
      >
        <div className="about-motion-field" aria-hidden="true">
          <i className="about-orbit about-orbit-one" />
          <i className="about-orbit about-orbit-two" />
          <i className="about-glow" />
          <i className="about-particle particle-one" />
          <i className="about-particle particle-two" />
          <i className="about-particle particle-three" />
        </div>
        <div className="about-statement">
          <p className="eyebrow"><span /> À propos d’OnwaysTech</p>
          <h2>La technologie utile,<br /><em>pensée pour l’humain.</em></h2>
          <i className="about-title-line" aria-hidden="true" />
          <p>Nous concevons des solutions numériques qui répondent à des besoins réels, créent de la valeur et accompagnent durablement les organisations.</p>
          <a href="#equipe">Rencontrer l’équipe <span>→</span></a>
        </div>
        <div className="about-values">
          <i className="about-flow-line" aria-hidden="true" />
          <article><span>01</span><b>Comprendre</b><p>Écouter le besoin avant d’imaginer la solution.</p></article>
          <article><span>02</span><b>Construire</b><p>Transformer les idées en produits simples et solides.</p></article>
          <article><span>03</span><b>Faire grandir</b><p>Créer des solutions capables d’évoluer dans le temps.</p></article>
          <div className="about-signature"><strong>OnwaysTech</strong><small>STRATÉGIE · DESIGN · TECHNOLOGIE</small></div>
        </div>
      </section>

      <section
        className={`team-page panel ${teamActive ? "team-active" : ""}`}
        id="equipe"
        ref={teamRef}
      >
        <a className="team-side-nav team-prev" href="#apropos" aria-label="Retour à la page À propos">
          <span>←</span><small>Retour</small>
        </a>
        <div className="team-heading">
          <p className="eyebrow"><span /> L’équipe OnwaysTech</p>
          <h2>Les talents<br /><em>derrière nos</em><br />solutions<span>.</span></h2>
          <i className="team-title-line" aria-hidden="true" />
          <p>Une équipe engagée qui transforme les idées en produits numériques utiles, simples et durables.</p>
          <a className="team-join" href="mailto:contact@onways.tech">
            Rejoindre l’équipe <span>→</span>
          </a>
        </div>
        <div className="team-grid">
          {teamMembers.map((member, index) => {
            const {portrait, name, role, detail, icon:Icon} = member;
            return (
            <article
              key={name}
              className={selectedMember?.name === name ? "member-selected" : ""}
              style={{"--delay": `${index * 70}ms`} as React.CSSProperties}
              role="button"
              tabIndex={0}
              aria-label={`Afficher la fiche de ${name}`}
              onClick={() => setSelectedMember(member)}
              onKeyDown={(event) => {
                if (event.key === "Enter" || event.key === " ") {
                  event.preventDefault();
                  setSelectedMember(member);
                }
              }}
            >
              <div className="member-card-top">
                <div className="member-portrait">
                  <img src={portrait} alt={`Portrait illustré de ${name}`} />
                </div>
                <span className={`member-icon-motion member-icon-motion-${index + 1}`} aria-hidden="true">
                  <Icon className="member-role-icon" />
                </span>
              </div>
              <i className="member-accent-line" aria-hidden="true" />
              <div className="member-copy">
                <b>{name}</b>
                <small>{role}{detail && <><br />{detail}</>}</small>
              </div>
            </article>
          )})}
        </div>
        <div className="team-tools-shell" aria-label="Outils maîtrisés par l’équipe">
          <div
            className={`team-tools-marquee ${toolsPaused ? "is-paused" : ""}`}
            ref={toolsMarqueeRef}
            onMouseEnter={() => setToolsPaused(true)}
            onMouseLeave={() => {
              if (!toolDragRef.current.active) setToolsPaused(false);
            }}
            onPointerDown={(event) => {
              const marquee = toolsMarqueeRef.current;
              if (!marquee) return;
              toolDragRef.current = { active:true, x:event.clientX, scrollLeft:marquee.scrollLeft };
              marquee.setPointerCapture(event.pointerId);
              setToolsPaused(true);
            }}
            onPointerMove={(event) => {
              const marquee = toolsMarqueeRef.current;
              if (!marquee || !toolDragRef.current.active) return;
              marquee.scrollLeft = toolDragRef.current.scrollLeft - (event.clientX - toolDragRef.current.x);
            }}
            onPointerUp={(event) => {
              toolDragRef.current.active = false;
              toolsMarqueeRef.current?.releasePointerCapture(event.pointerId);
              setToolsPaused(false);
            }}
          >
            <div className="team-tools-track">
              {[...teamTools, ...teamTools].map(({name, icon:ToolIcon}, index) => (
                <span className="tool-capsule" key={`${name}-${index}`} aria-hidden={index >= teamTools.length}>
                  <ToolIcon aria-hidden="true" />
                  <b>{name}</b>
                </span>
              ))}
            </div>
          </div>
        </div>
        <a className="team-side-nav team-next" href="#ecosysteme" aria-label="Passer à la page Écosystème">
          <span>→</span><small>Suivant</small>
        </a>
        <div className="team-progress" aria-label="Page Équipe">
          <i /><i /><i /><i /><i className="active" />
        </div>
        {selectedMember && (
          <div className="member-modal-backdrop" role="presentation" onMouseDown={() => setSelectedMember(null)}>
            <aside
              className="member-modal"
              role="dialog"
              aria-modal="true"
              aria-labelledby="member-modal-title"
              onMouseDown={(event) => event.stopPropagation()}
            >
              <button className="member-modal-close" type="button" onClick={() => setSelectedMember(null)} aria-label="Fermer la fiche">
                <X aria-hidden="true" />
              </button>
              <div className="member-modal-portrait">
                <img src={selectedMember.portrait} alt={`Portrait illustré de ${selectedMember.name}`} />
              </div>
              <p>ÉQUIPE ONWAYSTECH</p>
              <h3 id="member-modal-title">{selectedMember.name}</h3>
              <strong>{selectedMember.role}{selectedMember.detail ? ` — ${selectedMember.detail}` : ""}</strong>
              <dl>
                <div><dt>Responsabilités</dt><dd>{selectedMember.role}{selectedMember.detail ? `, ${selectedMember.detail}` : ""}.</dd></div>
                <div><dt>Compétences</dt><dd>Informations complémentaires à renseigner.</dd></div>
              </dl>
            </aside>
          </div>
        )}
      </section>

      <section className="ecosystem-page panel" id="ecosysteme">
        <div className="ecosystem-copy">
          <p className="eyebrow"><span /> Écosystème Onways</p>
          <h2>Une maison mère.<br /><em>Plusieurs innovations.</em></h2>
          <p><strong>WINTAX</strong> est l’entreprise mère qui porte la vision et a donné naissance à OnwaysTech ainsi qu’à ses produits numériques.</p>
          <div className="ecosystem-legend">
            <span><i className="legend-parent" /> Entreprise mère</span>
            <span><i className="legend-entity" /> Entité technologique</span>
            <span><i className="legend-product" /> Produits</span>
          </div>
          <a href="mailto:contact@onways.tech">Rejoindre l’écosystème <span>→</span></a>
        </div>
        <div className="ecosystem-canvas">
          <div className="eco-glow eco-glow-one" aria-hidden="true" />
          <div className="eco-glow eco-glow-two" aria-hidden="true" />
          <div className="eco-parent">
            <span>ENTREPRISE MÈRE</span>
            <b>WINTAX</b>
            <small>Vision · Gouvernance · Développement</small>
          </div>
          <div className="eco-trunk eco-trunk-top" aria-hidden="true"><i /></div>
          <article className="eco-tech">
            <small>ENTITÉ TECHNOLOGIQUE</small>
            <b>Onways<span>Tech</span></b>
            <p>Le studio qui imagine, structure et développe les solutions numériques du groupe.</p>
          </article>
          <div className="eco-trunk eco-trunk-products" aria-hidden="true"><i /></div>
          <div className="eco-products">
            <article className="eco-product node-pay">
              <small>FINTECH</small><b>OnwaysPay</b>
              <span>Services numériques du quotidien.</span>
            </article>
            <article className="eco-product node-speakf">
              <small>IA & FINANCE</small><b>SPeaKF</b>
              <span>Intelligence, outils et entreprises.</span>
            </article>
            <article className="eco-product node-newister">
              <small>TECHNOLOGIE BIBLIQUE</small><b>NeWisTer</b>
              <span>La technologie au service de DIEU.</span>
            </article>
          </div>
          <p className="eco-signature"><span /> Un même groupe · Une vision commune · Plusieurs solutions</p>
        </div>
        <footer><span>© 2026 OnwaysTech</span><span>Abidjan · Côte d’Ivoire</span><a href="mailto:contact@onways.tech">contact@onways.tech</a></footer>
      </section>

      <section
        className={`footer-page panel ${footerActive ? "footer-active" : ""}`}
        id="contact"
        ref={footerRef}
      >
        <div className="footer-copy">
          <p className="eyebrow"><span /> Une idée à concrétiser ?</p>
          <h2>Construisons<br /><em>la suite ensemble.</em></h2>
          <p className="footer-lead">
            Une application, une plateforme SaaS ou un projet numérique à
            structurer ? Notre équipe transforme votre ambition en solution
            utile, solide et évolutive.
          </p>
          <div className="footer-actions">
            <a className="footer-primary" href="mailto:contact@onways.tech">
              Démarrer un projet <span>↗</span>
            </a>
            <a className="footer-secondary" href="#devis">
              Estimer mon projet <span>→</span>
            </a>
          </div>
          <div className="footer-contact">
            <div><small>E-MAIL</small><a href="mailto:contact@onways.tech">contact@onways.tech</a></div>
            <div><small>LOCALISATION</small><strong>Abidjan · Côte d’Ivoire</strong></div>
          </div>
        </div>

        <div className="premium-stage" aria-label="Signature OnwaysTech">
          <div className="premium-halo halo-one" aria-hidden="true" />
          <div className="premium-halo halo-two" aria-hidden="true" />
          <div className="signature-card">
            <div className="signature-top">
              <span>ONWAYSTECH</span>
              <small>ABIDJAN · CÔTE D’IVOIRE</small>
            </div>
            <div className="signature-mark">
              <span className="brand-mark" aria-hidden="true"><span /></span>
            </div>
            <h3>La technologie utile,<br /><em>pensée pour l’impact.</em></h3>
            <div className="signature-pillars">
              <span>Stratégie</span><i />
              <span>Design</span><i />
              <span>Technologie</span>
            </div>
          </div>
          <div className="executive-portrait-card">
            <img
              src="/assets/egerie-costume-bras-croises-v2.png"
              alt="Égérie OnwaysTech en costume, les bras croisés"
            />
            <div>
              <small>VISAGE DE MARQUE</small>
              <strong>Une présence humaine,<br />une ambition numérique.</strong>
            </div>
          </div>
          <div className="premium-metrics">
            <article><strong>03</strong><span>Produits numériques</span></article>
            <article><strong>06</strong><span>Services spécialisés</span></article>
            <article><strong>01</strong><span>Vision connectée</span></article>
          </div>
        </div>

        <div className="footer-bottom">
          <a className="footer-brand" href="#accueil">
            <span className="brand-mark" aria-hidden="true"><span /></span>
            <span>Onways<span>.tech</span></span>
          </a>
          <div className="footer-nav">
            <a href="#produits">Produits</a>
            <a href="#services">Services</a>
            <a href="#apropos">À propos</a>
            <a href="#equipe">Équipe</a>
            <a href="#ecosysteme">Écosystème</a>
          </div>
          <div className="legal-links">
            <a href="/confidentialite">Confidentialité</a>
            <a href="/mentions-legales">Mentions légales</a>
            <a href="/conditions-utilisation">Conditions</a>
            <a href="/cookies">Cookies</a>
            <span>© 2026 OnwaysTech</span>
          </div>
        </div>
      </section>
      </div>

      <div className="scroll-hint" aria-hidden="true">
        <span>Molette ou touches directionnelles</span><i>→</i>
      </div>
    </main>
  );
}
