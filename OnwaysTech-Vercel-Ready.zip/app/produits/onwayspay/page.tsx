import ProductDetail, { ProductConfig } from "../ProductDetail";

const product: ProductConfig = {
  slug: "onwayspay",
  name: "OnwaysPay",
  mark: "O",
  eyebrow: "Services numériques utiles",
  title: "Tous vos services numériques,",
  accent: "en un seul endroit.",
  description: "OnwaysPay facilite l’accès aux opérations Mobile Money et aux services numériques du quotidien, depuis une interface simple, rapide et transparente.",
  promise: "Accéder à l’essentiel, simplement.",
  audience: ["Particuliers", "Professionnels", "Diaspora"],
  features: [
    { title: "Échange Mobile Money", text: "Passez d’un réseau à un autre entre Orange Money, MTN MoMo, Moov Money et Wave selon les disponibilités.", tag: "SERVICE PRINCIPAL" },
    { title: "Crédit & forfaits Internet", text: "Achetez du crédit téléphonique et des forfaits data pour les réseaux pris en charge." },
    { title: "Paiement de services", text: "Accédez au paiement de factures et de services numériques depuis un même parcours." },
    { title: "Cartes cadeaux", text: "Achetez des cartes cadeaux et contenus numériques auprès des fournisseurs intégrés." },
  ],
  steps: [
    { number: "01", title: "Choisissez un service", text: "Sélectionnez l’échange Mobile Money, le crédit, la data, une facture ou une carte cadeau." },
    { number: "02", title: "Renseignez l’opération", text: "Indiquez le réseau, le numéro, le montant ou le produit numérique recherché." },
    { number: "03", title: "Vérifiez les informations", text: "Consultez clairement les détails et les frais avant de confirmer." },
    { number: "04", title: "Finalisez avec le moyen disponible", text: "L’opération est exécutée à travers les partenaires et moyens de paiement intégrés." },
  ],
  benefits: ["Une seule interface pour plusieurs besoins", "Parcours clair et adapté aux usages locaux", "Aucun solde OnwaysPay stocké", "Frais présentés avant validation"],
  available: ["Échange Mobile Money", "Crédit téléphonique et data", "Paiement de services", "Cartes cadeaux numériques"],
  upcoming: ["Consultation liée aux cartes Visa, selon intégration", "Dons aux églises et ministères", "Nouveaux fournisseurs de services"],
};

export default function OnwaysPayPage() {
  return <ProductDetail product={product} />;
}
