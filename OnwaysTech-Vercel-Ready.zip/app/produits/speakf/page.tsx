import ProductDetail, { ProductConfig } from "../ProductDetail";

const product: ProductConfig = {
  slug: "speakf",
  name: "SPeaKF",
  mark: "SF",
  eyebrow: "Intelligence financière",
  title: "Comprendre vos finances.",
  accent: "Mieux décider.",
  description: "SPeaKF réunit une intelligence artificielle financière, des outils d’analyse et un environnement professionnel pour organiser, comprendre et développer vos activités.",
  promise: "Transformer vos données en décisions utiles.",
  audience: ["Entrepreneurs", "PME", "Organisations"],
  features: [
    { title: "Assistant financier IA", text: "Posez vos questions, analysez vos documents et obtenez des explications financières accessibles.", tag: "CŒUR DU PRODUIT" },
    { title: "Financial OS", text: "Suivez revenus, dépenses, budgets, caisse, rapprochements et indicateurs dans un espace structuré." },
    { title: "Business Docs", text: "Préparez plans d’affaires, rapports, procès-verbaux, prévisions et documents professionnels." },
    { title: "Business Studio", text: "Structurez modèle économique, stratégie, analyses, KPI et plan d’action." },
    { title: "Agenda intelligent", text: "Organisez réunions, tâches, échéances, documents et rappels professionnels." },
    { title: "Outils & simulations", text: "Accédez aux calculatrices, simulations de crédit, devises, marchés et comparaisons de frais." },
  ],
  steps: [
    { number: "01", title: "Créez votre espace", text: "Définissez votre profil, votre activité et les objectifs à suivre." },
    { number: "02", title: "Ajoutez vos informations", text: "Saisissez vos opérations ou importez les documents nécessaires à l’analyse." },
    { number: "03", title: "Interrogez l’intelligence", text: "Demandez une analyse, un document, une simulation ou un plan d’action." },
    { number: "04", title: "Pilotez vos décisions", text: "Suivez les recommandations, les indicateurs et les tâches depuis votre tableau de bord." },
  ],
  benefits: ["Finance expliquée en langage clair", "Documents professionnels réunis", "Organisation et analyse dans un seul espace", "Aide à la décision adaptée à l’activité"],
  available: ["Assistant IA et lecture de documents", "Outils financiers et calculatrices", "Business Docs", "Agenda et environnement de travail"],
  upcoming: ["Connexions bancaires selon partenaires", "Automatisations professionnelles avancées", "Nouveaux modèles sectoriels"],
};

export default function SPeaKFPage() {
  return <ProductDetail product={product} />;
}
