"use client";

import { useState } from "react";
import Link from "next/link";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  ChevronDown,
  ChevronUp,
  Mail,
  Sparkles,
} from "lucide-react";

export type ProductConfig = {
  slug: "onwayspay" | "speakf" | "newister";
  name: string;
  mark: string;
  eyebrow: string;
  title: string;
  accent: string;
  description: string;
  promise: string;
  audience: string[];
  features: { title: string; text: string; tag?: string }[];
  steps: { number: string; title: string; text: string }[];
  benefits: string[];
  available: string[];
  upcoming: string[];
};

export default function ProductDetail({ product }: { product: ProductConfig }) {
  const [activeTab, setActiveTab] = useState(0);
  const [expanded, setExpanded] = useState(false);

  return (
    <main className={`product-detail-page detail-${product.slug}`}>
      <header className="detail-header">
        <Link className="brand" href="/" aria-label="Retour à OnwaysTech">
          <span className="brand-mark" aria-hidden="true"><span /></span>
          <span className="brand-name">Onways<span>.tech</span></span>
        </Link>
        <nav className="detail-nav" aria-label="Navigation du produit">
          <Link href="/">Accueil</Link>
          <Link href="/#produits" className="active">Produits</Link>
          <Link href="/#services">Services</Link>
          <Link href="/#devis">Devis</Link>
        </nav>
        <a className="detail-contact" href="mailto:contact@onways.tech">
          <Mail aria-hidden="true" /> Nous contacter
        </a>
      </header>

      <section className="detail-hero">
        <div className="detail-copy">
          <Link className="back-products" href="/#produits"><ArrowLeft /> Tous les produits</Link>
          <p className="detail-eyebrow"><span /> {product.eyebrow}</p>
          <h1>{product.title}<em>{product.accent}</em></h1>
          <p className="detail-description">{product.description}</p>
          <div className="detail-actions">
            <a className="detail-primary" href="#explorer">
              Explorer le produit <ArrowRight />
            </a>
            <button type="button" onClick={() => setExpanded(!expanded)}>
              En savoir plus {expanded ? <ChevronUp /> : <ChevronDown />}
            </button>
          </div>
          <div className="product-audience">
            <small>CONÇU POUR</small>
            {product.audience.map((item) => <span key={item}>{item}</span>)}
          </div>
        </div>

        <div className="detail-visual" aria-label={`Aperçu de ${product.name}`}>
          <div className="detail-orbit orbit-wide" />
          <div className="detail-orbit orbit-tight" />
          <div className="product-emblem"><b>{product.mark}</b><span>{product.name}</span></div>
          <div className="preview-window">
            <div className="preview-top"><i /><i /><i /><span>{product.name}</span></div>
            <div className="preview-body">
              <aside><b>{product.mark}</b><i /><i /><i /><i /></aside>
              <div>
                <small>VOTRE ESPACE {product.name.toUpperCase()}</small>
                <strong>{product.promise}</strong>
                <div className="preview-cards">
                  {product.features.slice(0, 3).map((feature, index) => (
                    <article key={feature.title}><span>0{index + 1}</span><b>{feature.title}</b></article>
                  ))}
                </div>
                <div className="preview-line"><i /><i /><i /><i /></div>
              </div>
            </div>
          </div>
          <div className="floating-chip chip-top"><Sparkles /><span>Simple</span></div>
          <div className="floating-chip chip-side"><Check /><span>Utile</span></div>
        </div>
      </section>

      {expanded && (
        <section className="learn-more-panel" aria-label={`En savoir plus sur ${product.name}`}>
          <div><small>LA PROMESSE</small><strong>{product.promise}</strong></div>
          <p>{product.description} Cette page vous permet de découvrir progressivement le concept, les fonctions, le parcours utilisateur et l’état actuel du produit.</p>
          <a href="#explorer">Voir toutes les informations <ArrowRight /></a>
        </section>
      )}

      <section className="product-explorer" id="explorer">
        <div className="explorer-tabs" role="tablist" aria-label="Informations produit">
          {["Fonctionnalités", "Fonctionnement", "Avantages & disponibilité"].map((tab, index) => (
            <button
              type="button"
              key={tab}
              className={activeTab === index ? "active" : ""}
              onClick={() => setActiveTab(index)}
              role="tab"
              aria-selected={activeTab === index}
            >
              <span>0{index + 1}</span>{tab}
            </button>
          ))}
        </div>

        <div className="explorer-content">
          {activeTab === 0 && (
            <div className="feature-detail-grid">
              {product.features.map((feature, index) => (
                <article key={feature.title}>
                  <span>{String(index + 1).padStart(2, "0")}</span>
                  <div><h2>{feature.title}</h2><p>{feature.text}</p></div>
                  {feature.tag && <small>{feature.tag}</small>}
                </article>
              ))}
            </div>
          )}

          {activeTab === 1 && (
            <div className="steps-detail">
              {product.steps.map((step) => (
                <article key={step.number}>
                  <b>{step.number}</b><div><h2>{step.title}</h2><p>{step.text}</p></div>
                </article>
              ))}
            </div>
          )}

          {activeTab === 2 && (
            <div className="availability-grid">
              <div className="benefits-list">
                <small>POURQUOI {product.name.toUpperCase()} ?</small>
                {product.benefits.map((benefit) => <p key={benefit}><Check />{benefit}</p>)}
              </div>
              <div className="status-card available">
                <small>PRÉSENTÉ DANS LE PRODUIT</small>
                {product.available.map((item) => <p key={item}><i />{item}</p>)}
              </div>
              <div className="status-card upcoming">
                <small>ÉVOLUTIONS PRÉVUES</small>
                {product.upcoming.map((item) => <p key={item}><i />{item}</p>)}
              </div>
            </div>
          )}
        </div>
      </section>

      <section className="product-final-cta">
        <div><small>UN PROJET AUTOUR DE {product.name.toUpperCase()} ?</small><h2>Parlons de la prochaine étape.</h2></div>
        <div>
          <Link href="/#devis">Demander un devis <ArrowRight /></Link>
          <a href="mailto:contact@onways.tech">Échanger avec OnwaysTech</a>
        </div>
      </section>
    </main>
  );
}
