import ProductDetail, { ProductConfig } from "../ProductDetail";

const product: ProductConfig = {
  slug: "newister",
  name: "NeWisTer",
  mark: "✦",
  eyebrow: "Intelligence biblique",
  title: "La technologie",
  accent: "au service de DIEU.",
  description: "NeWisTer associe une intelligence artificielle biblique, des ressources d’étude et des outils numériques pour accompagner les croyants, les églises et les ministères.",
  promise: "Étudier, trouver et mieux organiser.",
  audience: ["Croyants", "Églises", "Ministères"],
  features: [
    { title: "Assistant biblique", text: "Posez une question et explorez les Écritures avec des réponses structurées et des références bibliques.", tag: "MVP PRIORITAIRE" },
    { title: "Bible & recherche", text: "Recherchez passages, thèmes, personnages et ressources pour approfondir votre étude." },
    { title: "Études, plans & notes", text: "Créez des plans de lecture, conservez vos notes et organisez vos favoris." },
    { title: "NeWisTer Référence", text: "Trouvez une église ou un ministère par lieu, langue, dénomination, programme ou proximité." },
    { title: "Gestion d’église", text: "Organisez membres, groupes, événements, départements, ressources et activités ecclésiastiques." },
    { title: "NeWisTer Création", text: "Créez ou améliorez l’identité visuelle d’une église : logo, couleurs, typographies et charte." },
  ],
  steps: [
    { number: "01", title: "Choisissez votre univers", text: "Entrez dans l’espace biblique personnel, la référence chrétienne ou la gestion d’organisation." },
    { number: "02", title: "Recherchez ou organisez", text: "Posez une question biblique, trouvez une église ou gérez les informations de votre ministère." },
    { number: "03", title: "Créez votre espace", text: "Sauvegardez vos études ou configurez la page officielle de votre organisation." },
    { number: "04", title: "Progressez dans la durée", text: "Retrouvez vos ressources, programmes, membres et outils depuis un même environnement." },
  ],
  benefits: ["Recherche biblique plus accessible", "Ressources personnelles organisées", "Visibilité vérifiée pour les églises", "Outils adaptés aux organisations chrétiennes"],
  available: ["Assistant biblique et recherche", "Études, plans, notes et favoris", "Comptes utilisateurs", "Administration essentielle"],
  upcoming: ["Annuaire chrétien intelligent NeWisTer Référence", "Gestion complète d’église et de ministère", "Services d’identité visuelle NeWisTer Création"],
};

export default function NeWisTerPage() {
  return <ProductDetail product={product} />;
}
